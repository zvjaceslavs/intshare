
/etc/zabbix/zabbix_agentd.conf.d/nut-ups.conf
/usr/local/sbin/nut-ups.sh
