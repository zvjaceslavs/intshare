Zabbix-NUT-Template
===================

Zabbix Template for NUT(Network UPS Tools)

Supported UPS: http://www.networkupstools.org/stable-hcl.html
