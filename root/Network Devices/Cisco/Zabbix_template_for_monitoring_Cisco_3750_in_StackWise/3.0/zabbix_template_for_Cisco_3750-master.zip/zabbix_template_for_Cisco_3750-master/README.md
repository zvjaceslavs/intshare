# Zabbix template for monitoring Cisco 3750 in StackWise

CISCO-STACKWISE-MIB
