#!/bin/bash
####
#### Script para coletar informações do radio SIAE AGS20 via SNMP
#### MODULAÇÃO | SINAL | SNR | TEMPERATURA | UPTIME
##
## Changelog 0.1b
##   Adicionado a coleta de Uptime
##   Unificação de todos os módulos de coleta em apenas um script.
##   12-02-2019
##
#################################
#### Upnet Telecom 2019 
####
#### wesley.farias@gmail.com
#################################

###variaveis
snmp_community="your_community"
mibdir=/opt/siae_mibs
mibsys=$mibdir/sm_radiosys.mib
mibtemp=$mibdir/sm_tsens.mib

function HowToUseIt() {
	clear
	echo
	echo "Como utilizar o script para coletar dados do radio SIAE"
	echo "--------------------------------------------------------"
	echo "Opções:"
	echo
	echo "  -m 			 	Modulação"
	echo "  -s			 	Nível de Sinal"
	echo "  -r			 	SNR (Signal to Noise)"
	echo "  -t			 	Temperatura"
	echo "  -u			 	Uptime"
	echo "  -h			 	Ajuda"
	echo "  -v			 	Versão"
	echo "  -A | -B | -Z			Representa a ODU A, ODU B, e ODU A e B respectivamente."
	echo "				Essa opção deve ser usada quando utilizar as opções -m -s -r"
	echo "				para especificar qual ODU deseja ver a informação"
	echo
	echo "Verificar modulação da ODU A"
	echo "  Exemplo1: `basename $0` -m -A 192.168.150.1"
	echo 
	echo "Verificar nível de sinal da ODU B"
	echo "  Exemplo2: `basename $0` -s -B 192.168.150.1"
	echo
	echo "Verificar SNR da ODU A e B"
	echo "  Exemplo3: `basename $0` -r -Z 192.168.150.1"
	echo 
	echo
}

while getopts "msrABZtuhv" OPTION
do
	case $OPTION in
		h) HowToUseIt
		   ;;
		v) echo "Versão: 0.1b"
		   exit
		   ;;
	        m) MODULATION=1
		     getopts "ABZ" M_OPTION
	                 case $M_OPTION in
		           A) M_ODU_A=1
		              ;;
	                   B) M_ODU_B=1
	                      ;;
                           Z) M_ODU_AB=1
                              ;;
                          esac
                   ;;
                s) SIGNAL=1
		     getopts "ABZ" S_OPTION
                         case $S_OPTION in
                           A) S_ODU_A=1
                              ;;
                           B) S_ODU_B=1
                              ;;
                           Z) S_ODU_AB=1
                              ;;
                          esac
                   ;;
 		 r) SNR=1
		      getopts "ABZ" R_OPTION
                         case $R_OPTION in
                           A) R_ODU_A=1
                              ;;
                           B) R_ODU_B=1
                              ;;
                           Z) R_ODU_AB=1
                              ;;
                          esac
                   ;;
	         t) TEMP=1
	           ;;
                 u) UPTIME=1
      		   ;;
		 ?) HowToUseIt
                   ;;
	esac
done
 


shift $((OPTIND-1))

if [ -z "$MODULATION" ] && [ -z "$SIGNAL" ] && [ -z "$SNR" ] && [ -z "$TEMP" ] && [ -z "$UPTIME" ];  then
      HowToUseIt
fi

if [ "$MODULATION" == 1 ] && [ -z "$M_ODU_A" ] && [ -z "$M_ODU_B" ] && [ -z "$M_ODU_AB" ]; then
	HowToUseIt
else
	if [ "$M_ODU_A" == 1 ]; then
		snmpwalk -On -v2c -c $snmp_community $1 -m $mibsys linkAcmRxModulation |cut -f 2 -d : |sed 's/ //g' |sed 's/bps//g' |sed -n '1p' |sed 's/(11)\|(10)\|(9)\|(8)\|(7)\|(6)\|(5)\|(4)\|(3)\|(2)\|(1)\|(0)//g'
	fi
	if [ "$M_ODU_B" == 1 ]; then
		snmpwalk -On -v2c -c $snmp_community $1 -m $mibsys linkAcmRxModulation |cut -f 2 -d : |sed 's/ //g' |sed 's/bps//g' |sed -n '2p' |sed 's/(11)\|(10)\|(9)\|(8)\|(7)\|(6)\|(5)\|(4)\|(3)\|(2)\|(1)\|(0)//g'
	fi
	if [ "$M_ODU_AB" == 1 ]; then
		snmpwalk -On -v2c -c $snmp_community $1 -m $mibsys linkAcmRxModulation |cut -f 2 -d : |sed 's/ //g' |sed 's/bps//g' |sed 's/(11)\|(10)\|(9)\|(8)\|(7)\|(6)\|(5)\|(4)\|(3)\|(2)\|(1)\|(0)//g'
	fi

fi

if [ "$SIGNAL" == 1 ] && [ -z "$S_ODU_A" ] && [ -z "$S_ODU_B" ] && [ -z "$S_ODU_AB" ]; then
	HowToUseIt
else
	if [ "$S_ODU_A" == 1 ]; then
		snmpwalk -On -v2c -c $snmp_community $1 -m $mibsys radioPrx |cut -f 2 -d : |sed 's/ //g' |sed -n '1p' # |sed 's/-//'
	fi
	if [ "$S_ODU_B" == 1 ]; then
		snmpwalk -On -v2c -c $snmp_community $1 -m $mibsys radioPrx |cut -f 2 -d : |sed 's/ //g' |sed -n '2p' # |sed 's/-//'
	fi
	if [ "$S_ODU_AB" == 1 ]; then
		snmpwalk -On -v2c -c $snmp_community $1 -m $mibsys radioPrx |cut -f 2 -d : |sed 's/ //g' # |sed 's/-//'
	fi

fi

if [ "$SNR" == 1 ] && [ -z "$R_ODU_A" ] && [ -z "$R_ODU_B" ] && [ -z "$R_ODU_AB" ]; then
	HowToUseIt
else
	if [ "$R_ODU_A" == 1 ]; then
		snmpwalk -On -v2c -c $snmp_community $1 -m $mibsys radioNormalizedMse |cut -f 2 -d : |sed 's/ //g' |sed 's/.\{2\}/&./' |sed -n '1p'
	fi
	if [ "$R_ODU_B" == 1 ]; then
		snmpwalk -On -v2c -c $snmp_community $1 -m $mibsys radioNormalizedMse |cut -f 2 -d : |sed 's/ //g' |sed 's/.\{2\}/&./' |sed -n '2p'
	fi
	if [ "$R_ODU_AB" == 1 ]; then
		snmpwalk -On -v2c -c $snmp_community $1 -m $mibsys radioNormalizedMse |cut -f 2 -d : |sed 's/ //g' |sed 's/.\{2\}/&./'
	fi
fi

if [ "$TEMP" == 1 ]; then
	if [ $# -lt 1 ]; then
		HowToUseIt
	else
	snmpwalk -On -v2c -c $snmp_community $1 -m $mibtemp sensorTempValue |sed -n '1p' |cut -f 2 -d : |sed 's/ //g'
fi
fi

if [ "$UPTIME" == 1 ]; then
	if [ $# -lt 1 ]; then
		HowToUseIt
	else
	# formato humano
#	snmpwalk -On -v2c -c $snmp_community $1 -m $mibsys sysUpTime |cut -f 2 -d ')' |sed 's/^ //g'
echo `snmpwalk -On -v2c -c $snmp_community $1 -m $mibsys sysUpTime |cut -f 2 -d'(' |cut -f 1 -d')'` / 86400 / 100 | bc -l
	#formato timestamp
#	echo `snmpwalk -On -v2c -c $snmp_community $1 -m $mibsys sysUpTime |cut -f 2 -d'(' |cut -f 1 -d')'`

fi
fi
