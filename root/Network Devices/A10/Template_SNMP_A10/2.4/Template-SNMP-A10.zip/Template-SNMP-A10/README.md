# Template-SNMP-A10

Zabbix Template for A10 network

Execute valuemaps.sql and mappings.sql before import this template

There may some faults,please help me find it. :)

##Import guide

Before import,please execute the two sql file.I use some valuemaps in thie template.

Attention,please view two sql files before you import them.

##导入向导

在导入之前，请先执行两个sql文件，我用了一下对应值在里面.

注意,默认会删掉之前的数据,请自行修改.

##截图

![](https://github.com/0312birdzhang/Template-SNMP-A10/blob/master/zzh.jpg)
