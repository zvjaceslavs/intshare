Zyxel-NXC5500-WLAN-controller


Features:
- Base information of Controler
- Discovery ALL AP (MAC,IP,Number of clients)
- Check ALL AP of ICMP Ping, ICMP Loss, ADMIN Status
- Graph of AP Ping, Loss, Total Clients


Later add these features (when there will be more time :)
- List of SSIDs on each AP
- no Clients on each SSID
- no Clients on 2,4 or 5 Ghz radio mode
- List of assigned Clients (IP,MAC,etc..)
- List of wirelless channels on each AP
- etc...

If you are interested, you can contact me and add a function, but I do not think that they are still particularly necessary for routine monitoring.
priechodsky.dusan@gmail.com
