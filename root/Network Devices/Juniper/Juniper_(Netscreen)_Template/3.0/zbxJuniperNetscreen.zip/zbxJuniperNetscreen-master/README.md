# zbxJuniperNetscreen
Zabbix template for Netscreen based Juniper devices, tested with Juniper SSG140.

No MIBs required.

* Device status monitoring, with triggers
* Interfaces monitoring, with "Interface went down" trigger.
* VPN tunnels monitoring, with "Tunnel down" trigger.

Some graphs added as well.

Created and tested in Zabbix v3.0.
