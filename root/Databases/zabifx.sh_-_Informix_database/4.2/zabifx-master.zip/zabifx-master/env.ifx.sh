if [ -x /home/informix/env.ifx.sh ] ; then 
  source /home/informix/env.ifx.sh 
fi

