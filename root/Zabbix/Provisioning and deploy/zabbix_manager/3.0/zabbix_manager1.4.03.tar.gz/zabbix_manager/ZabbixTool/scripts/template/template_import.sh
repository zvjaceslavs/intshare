#########################################################################
# File Name: template_import.sh
# Author: Bill
# mail: XXXXXXX@qq.com
# Created Time: 2016-06-22 16:30:11
#########################################################################
#!/bin/bash
python ./lib_zabbix/zabbix_api.py --template_import ./scripts/template/ceshi_templates.xml
