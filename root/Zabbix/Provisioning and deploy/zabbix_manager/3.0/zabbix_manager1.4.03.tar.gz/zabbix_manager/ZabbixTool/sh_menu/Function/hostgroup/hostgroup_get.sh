#########################################################################
# File Name: hostgroup_get.sh
# Author: 遇见王斌
# mail: meetbill@163.com
# Created Time: 2016-11-27 16:53:17
#########################################################################
#!/bin/bash
zabbix_api hostgroup_get --table

