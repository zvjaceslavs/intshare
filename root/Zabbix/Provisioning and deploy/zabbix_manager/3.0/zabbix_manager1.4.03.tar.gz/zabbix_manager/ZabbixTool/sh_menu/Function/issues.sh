#!/bin/bash
#########################################################################
# File Name: issues.sh
# Author: meetbill
# mail: meetbill@163.com
# Created Time: 2017-06-10 08:34:45
#########################################################################
zabbix_api issues --table

