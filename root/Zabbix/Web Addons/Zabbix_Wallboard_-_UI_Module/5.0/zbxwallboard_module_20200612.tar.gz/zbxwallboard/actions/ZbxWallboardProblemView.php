<?php

namespace Modules\ZbxWallboard\Actions;

class ZbxWallboardProblemView extends \CControllerProblemView {

}
