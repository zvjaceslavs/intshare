/* $Id: zrpc.h,v 1.5 2020/12/29 20:38:47 absc Exp $ */
/*
 * Copyright (c) 2018 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef _ZRPC_H_
#define _ZRPC_H_

enum types {
	VFLOAT,
	VCHAR,
	VLOG,
	VNUM,
	VTEXT,
	VERR
};

struct valtype {
	enum	types type;
	char	*key;
};

enum itype {
	ITMPSV,
	ITMSNMPV1,
	ITMTRP,
	ITMSMPL,
	ITMSNMPV2,
	ITMITRN,
	ITMSNMPV3,
	ITMACT,
	ITMAGG,
	ITMWEB,
	ITMEXT,
	ITMDB,
	ITMIPMI,
	ITMSSH,
	ITMTLNT,
	ITMCALC,
	ITMJMX,
	ITMSNMPT,
	ITMDEP,
	ITMHTTP,
	ITMERR = 255
};

enum itstatus {
	ITMSTENABLED,
	ITMSTDISABLED,
	ITMSTERR = 255
};

enum hoststatus {
	HOSTSTENABLED,
	HOSTSTDISABLED,
	HOSTSTERR = 255
};

struct itemtype {
	enum	itype type;
	char	*key;
};

enum severity {
	TRGNC,
	TRGINF,
	TRGWARN,
	TRGAVG,
	TRGHIGH,
	TRGDIS,
	TRGERR = 255
};

enum authprototype {
	APMD5 = 0,
	APSHA,
	APERR = 255
};

struct authproto {
	enum	authprototype type;
	char	*key;
};

enum privprototype {
	PPROTODES = 0,
	PPROTOAES,
	PPROTOERR = 255
};

struct privproto {
	enum	privprototype type;
	char	*key;
};

struct trigsev {
	enum	severity sev;
	char	*key;
};

typedef enum {
	ZRPCFALSE,
	ZRPCTRUE,
	ZRPCERR
} zrpcbool;

typedef enum {
	ACTCLOSE = 1,
	ACTACK = 2,
	ACTMSG = 4,
	ACTSEV = 8,
	ACTUNACK = 16,
	ACTERR = 255
} zrpcaction;

enum ifacetype {
	IFAGENT = 1,
	IFSNMP,
	IFIPMI,
	IFJMX,
	IFERR = 255
};

enum snmptype {
	SNMPv1 = 1,
	SNMPv2c,
	SNMPv3,
	SNMPERR = 255
};

struct iface {
	enum	ifacetype type;
	char	*key;
};

struct snmp {
	enum	snmptype type;
	char	*key;
};

enum evsource {
	EVTTRG,
	EVTDSC,
	EVTAUTOR,
	EVTINTR,
	EVTERR = 255
};

struct evsrc {
	enum	evsource source;
	char	*key;
};

enum evobjtype {
	EVOBJTRG,
	EVOBJDSCHOST,
	EVOBJDSCSRV,
	EVOBJAUTOREG,
	EVOBJITM,
	EVOBJLLD,
	EVOBJERR = 255
};

enum secleveltype {
	SLNOAUTHNOPRIV = 0,
	SLAUTHNOPRIV,
	SLAUTHPRIV,
	SLERR = 255
};

struct seclevel {
	enum secleveltype	type;
	char		*key;
};

struct evobj {
	enum 	evobjtype type;
	char	*key;
};

struct evstate {
	unsigned	int state;
	char	*key[3];
};

typedef size_t (*streamcb)(char *, size_t, size_t, void *);

struct zrpc {
	struct		curl_slist *hdr;
	char		url[URLLEN];
	char		tok[TOKLEN];
	CURL		*hnd;
	char		*b;
	char		*np;
	size_t		s;
	size_t		bs;
	jsmntok_t		*tk;
	int		cp;
	int		tc;
};

typedef enum {
	JSONV_VAL,
	JSONV_OBJ,
	JSONV_ARR,
	JSONV_STR
} jsont;

struct jsonv {
	char	*str;
	size_t	size;
	jsont	type;
};

int		 zrpcglobalinit(char **);
struct zrpc	*zrpcinit(const char *, const char *, const char *, streamcb);
void		 zrpcfree(struct zrpc *);
int		 zrpcaddstr(struct zrpc *, const char *, const char *);
int		 zrpcaddint(struct zrpc *, const char *, long long);
int		 zrpcaddbool(struct zrpc *, const char *, zrpcbool);
int		 zrpcaddobj(struct zrpc *, const char *);
int		 zrpccloseobj(struct zrpc *);
int		 zrpcaddarray(struct zrpc *, const char *);
int		 zrpcclosearray(struct zrpc *);
int		 zrpcaddnull(struct zrpc *, const char *);
int		 zrpcclose(struct zrpc *);
int		 zrpcdo(struct zrpc *);

int		 zrpcjsonnext(struct zrpc *, struct jsonv *);
char		*zrpcgeterror(struct zrpc *);

#endif /* !_ZRPC_H_ */
