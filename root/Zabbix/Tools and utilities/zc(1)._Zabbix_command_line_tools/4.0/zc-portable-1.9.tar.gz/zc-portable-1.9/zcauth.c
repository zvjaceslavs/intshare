/* $Id: zcauth.c,v 1.3 2020/03/23 20:37:41 absc Exp $ */
/*
 * Copyright (c) 2018 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>

#include <err.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

static __dead void	usage(void);
static int		auth(struct zrpc *, const char *, const char *);

int
main(int argc, char *argv[])
{
	struct jsonv	val;
	char		fp[PATH_MAX];
	struct zrpc	*rpc;
	FILE		*f;
	int		c;
	const char	*un, *p;
	char		*error;

	un = DEFUSER;
	p = DEFPASSWD;

	if (pledge("cpath dns inet rpath stdio unveil wpath", NULL) == -1)
		err(1, "%s", "pledge");

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");

	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "cw") == -1)
		err(1, "%s", "unveil");

	while ((c = getopt(argc, argv, "u:p:")) != -1) {
		switch (c) {
		case 'u':
			if (strlen(optarg) >= USERLEN)
				errx(1, "%s", "Username too long");
			un = optarg;
			break;
		case 'p':
			if (strlen(optarg) >= PASSWDLEN)
				errx(1, "%s", "Password too long");
			p = optarg;
			break;
		case '?':
			usage();
		}
	}
	argc -= optind;
	argv += optind;

	if (argc == 0)
		errx(1, "%s", "missing zabbix server URL");

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	rpc = zrpcinit(*argv, "user.login", NULL, NULL);
	if (!rpc)
		errx(2, "%s", "error while initializing rpc structure");

	if (auth(rpc, un, p) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("cpath stdio wpath", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL)
			continue;
		if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
		else if (strcmp(val.str, "result") == 0) {
			zrpcjsonnext(rpc, &val);
			break;
		}
	}

	if (!val.str)
		errx(4, "%s", rpc->b);

	f = fopen(fp, "w");
	if (!f)
		err(4, "%s %s", fp, "fopen");

	fwrite(*argv, sizeof(char), strlen(*argv), f);
	if (ferror(f))
		err(4, "%s", "fwrite");
	if (fputc('\n', f) == EOF)
		err(4, "%s", "fputc");
	fwrite(val.str, sizeof(char), strlen(val.str), f);
	if (ferror(f))
		err(4, "%s", "fwrite");
	if (fputc('\n', f) == EOF)
		err(4, "%s", "fputc");

	return 0;
}

static __dead void
usage(void)
{
	fprintf(stderr, "%s: %s %s\n", "usage", getprogname(),
	    "[-p password] [-u user] url");

	exit(1);
}

static int
auth(struct zrpc *rpc, const char *us, const char *p)
{
	if (zrpcaddobj(rpc, "params") == -1)
		return -1;
	if (zrpcaddstr(rpc, "user", us) == -1)
		return -1;
	if (zrpcaddstr(rpc, "password", p) == -1)
		return -1;
	if (zrpccloseobj(rpc) == -1)
		return -1;
	if (zrpcclose(rpc) == -1)
		return -1;

	return zrpcdo(rpc);
}
