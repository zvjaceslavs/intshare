/* $Id: zctriggeradd.c,v 1.3 2020/12/28 09:57:18 absc Exp $ */
/*
 * Copyright (c) 2018 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>

#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

extern struct trigsev severities[];

static __dead void	usage(void);
static int		adddeps(struct zrpc *, char **);
static int		addtags(struct zrpc *, char **);

int
main(int argc, char *argv[])
{
	struct jsonv	val;
	struct zrpc	*rpc;
	struct trigsev	*np;
	int		c, s;
	char		fp[PATH_MAX];
	char		*dep[ARRLEN], *tag[ARRLEN];
	char		url[URLLEN], tok[TOKLEN];
	char		*error, **dp, *nm, *re, **tp, *turl, *ct;
	char		mp, mc;
	enum severity	sv;

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "r") == -1)
		err(1, "%s", "unveil");

	if (pledge("dns rpath stdio inet", NULL) == -1)
		err(1, "%s", "pledge");

	tp = tag;
	dp = dep;
	*tp = *dp = turl = re = ct = nm = NULL;
	sv = TRGNC;
	mp = mc = 0;
	while ((c = getopt(argc, argv, "amc:d:n:r:s:t:u:")) != -1)
		switch (c) {
		case 'a':
			mc = 1;
			break;
		case 'm':
			mp = 1;
			break;
		case 'c':
			ct = optarg;
			break;
		case 'd':
			if (dp == dep + ARRLEN)
				errx(1, "too many dependencies.");
			*dp++ = optarg;
			*dp = NULL;
			break;
		case 'n':
			nm = optarg;
			break;
		case 'r':
			re = optarg;
			break;
		case 's':
			for (np = severities; np->sev != TRGERR; np++)
				if (strcmp(optarg, np->key) == 0)
					sv = np->sev;
			break;
		case 't':
			if (tp == tag + ARRLEN)
				errx(1, "too many tags.");
			*tp++ = optarg;
			*tp = NULL;
			break;
		case 'u':
			turl = optarg;
			break;
		case '?':
			usage();
		}
	argc -= optind;
	argv += optind;
	if (!nm)
		errx(1, "%s", "missing trigger description");
	if (argc == 0)
		errx(1, "%s", "missing trigger expression");

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	if (getauthinfo(url, tok, NULL) == -1)
		err(1, "%s", fp);

	rpc = zrpcinit(url, "trigger.create", tok, NULL);
	if (!rpc)
		errx(2, "%s", "failed to initialized rpc structure");

	if (zrpcaddobj(rpc, "params") == -1)
		errx(2, "%s", "error while adding \"params\" object");
	if (zrpcaddstr(rpc, "expression", *argv) == -1)
		errx(2, "%s", "error while adding \"expression\" object");
	if (zrpcaddstr(rpc, "description", nm) == -1)
		errx(2, "%s", "error while adding \"description\" object");
	if (zrpcaddint(rpc, "severity", sv) == -1)
		errx(2, "%s", "error while adding \"severity\" object");
	if (zrpcaddint(rpc, "type", mp) == -1)
		errx(2, "%s", "error while adding \"type\" object");
	if (zrpcaddint(rpc, "manual_close", mc) == -1)
		errx(2, "%s", "error while adding \"manual_close\" object");
	if (zrpcaddint(rpc, "priority", sv) == -1)
		errx(2, "%s", "error while adding \"priority\" object");

	if (turl)
		if (zrpcaddstr(rpc, "url", turl) == -1)
			errx(2, "%s", "error while adding \"url\" object");

	if (re) {
		if (zrpcaddint(rpc, "recovery_mode", 1) == -1)
			errx(2, "%s", "error while adding \"recovery_mode\" "
			    "object");
		if (zrpcaddstr(rpc, "recovery_expression", re) == -1)
			errx(2, "%s", "error while adding \"recovery_expression\" "
			    "object");
	}

	if (ct) {
		if (zrpcaddint(rpc, "correlation_mode", 1) == -1)
			errx(2, "%s", "error while adding \"correlation_mode\" "
			    "object");
		if (zrpcaddstr(rpc, "correlation_tag", ct) == -1)
			errx(2, "%s", "error while adding \"correlation_tag\" "
			    "object");
	}

	if (*dep)
		if (adddeps(rpc, dep) == -1)
			errx(2, "%s", "error while adding dependencies");

	if (*tag)
		if (addtags(rpc, tag) == -1)
			errx(2, "%s", "error while adding tags");

	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing object");
	if (zrpcclose(rpc) == -1)
		errx(2, "%s", "error while closing payload");

	if (zrpcdo(rpc) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("stdio", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL &&
		    val.type != JSONV_ARR)
			continue;
		if (val.type == JSONV_ARR) {
			for (s = val.size; s > 0; s--) {
				if (zrpcjsonnext(rpc, &val) == -1)
					return 3;
				printf("%s\n", val.str);
			}
		} else if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
	}

	return 0;
}

static __dead void
usage(void)
{
	fprintf(stderr, "%s: %s %s %s %s %s %s %s %s %s %s\n", "usage",
	    getprogname(), "[-am]", "[-c correlation tag]", "[-d trigger dep]",
	    "[-n description]", "[-r recovery exp]", "[-s severity]",
	    "[-t tag|tag=value]", "[-u url]", "key");
	exit(1);
}

static int
adddeps(struct zrpc *rpc, char **deps)
{
	char	**np;

	if (zrpcaddarray(rpc, "dependencies") == -1)
		return -1;

	for (np = deps; *np; np++) {
		if (zrpcaddobj(rpc, NULL) == -1)
			return -1;
		if (zrpcaddstr(rpc, "triggerid", *np) == -1)
			return -1;
		if (zrpccloseobj(rpc) == -1)
			return -1;
	}

	if (zrpcclosearray(rpc) == -1)
		return -1;

	return 0;
}

static int
addtags(struct zrpc *rpc, char **tags)
{
	char	**np, *tag, *val;

	if (zrpcaddarray(rpc, "tags") == -1)
		return -1;

	for (np = tags; *np; np++) {
		val = *np;
		tag = strsep(&val, "=");
		if (zrpcaddobj(rpc, NULL) == -1)
			return -1;
		if (zrpcaddstr(rpc, "tag", tag) == -1)
			return -1;
		if (val)
			if (zrpcaddstr(rpc, "value", val) == -1)
				return -1;
		if (zrpccloseobj(rpc) == -1)
			return -1;
	}

	if (zrpcclosearray(rpc) == -1)
		return -1;

	return 0;
}
