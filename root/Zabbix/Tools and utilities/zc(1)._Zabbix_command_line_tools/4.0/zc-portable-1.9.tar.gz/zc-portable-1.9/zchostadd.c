/* $Id: zchostadd.c,v 1.4 2020/12/28 09:57:18 absc Exp $ */
/*
 * Copyright (c) 2018 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>

#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

#define HGLEN		8
#define TPLEN		16

static __dead void	usage(void);
static int		addinterface(struct zrpc *, char *, char *, char *);
static int		addgroups(struct zrpc *, char **);
static int		addtemplates(struct zrpc *rpc, char **);

int
main(int argc, char *argv[])
{
	struct jsonv	val;
	char		fp[PATH_MAX];
	char		*grp[HGLEN], *tmpl[TPLEN];
	char		url[URLLEN], tok[TOKLEN];
	char		*error, **grpp, **tmpp;
	char		*ip, *dns, *port;
	struct zrpc	*rpc;
	int		c, s;

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "r") == -1)
		err(1, "%s", "unveil");

	if (pledge("dns rpath stdio inet", NULL) == -1)
		err(1, "%s", "pledge");

	ip = DEFAULTIP;
	port = DEFAULTPORT;
	dns = NULL;
	grpp = grp;
	tmpp = tmpl;
	*grpp = NULL;
	*tmpp = NULL;
	while ((c = getopt(argc, argv, "d:g:i:p:t:")) != -1)
		switch (c) {
		case 'd':
			dns = optarg;
			break;
		case 'g':
			if (grpp == grp + HGLEN)
				errx(1, "too many hostgroups specified.");
			*grpp++ = optarg;
			*grpp = NULL;
			break;
		case 'i':
			ip = optarg;
			break;
		case 'p':
			port = optarg;
			break;
		case 't':
			if (tmpp == tmpl + TPLEN)
				errx(1, "too many templates specified.");
			*tmpp++ = optarg;
			*tmpp = NULL;
			break;
		case '?':
			usage();
		}
	argc -= optind;
	argv += optind;
	if (argc == 0) {
		warnx("%s", "hostname not provided.");
		usage();
	}

	if (getauthinfo(url, tok, NULL) == -1)
		err(1, "%s", fp);

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	rpc = zrpcinit(url, "host.create", tok, NULL);
	if (!rpc)
		errx(2, "%s", "failed to initialized rpc structure");

	if (zrpcaddobj(rpc, "params") == -1)
		errx(2, "%s", "error while adding \"params\" object");
	if (zrpcaddstr(rpc, "host", *argv) == -1)
		errx(2, "%s", "error while adding the \"host\" object");
	if (addinterface(rpc, ip, dns, port) == -1)
		errx(2, "%s", "error while adding the host ip");
	if (addgroups(rpc, grp) == -1)
		errx(2, "%s", "error while adding the host groups");
	if (addtemplates(rpc, tmpl) == -1)
		errx(2, "%s", "error while adding the templates");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing an object");
	if (zrpcclose(rpc) == -1)
		errx(2, "%s", "error while closing payload");
	if (zrpcdo(rpc) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("stdio", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL &&
		    val.type != JSONV_ARR)
			continue;
		if (val.type == JSONV_ARR) {
			for (s = val.size; s > 0; s--) {
				if (zrpcjsonnext(rpc, &val) == -1)
					return 3;
				printf("%s\n", val.str);
			}
		} else if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
	}

	return 0;
}

static __dead void
usage(void)
{
	fprintf(stderr, "%s: %s %s %s %s %s %s\n", "usage", getprogname(),
	    "[-g hostgroupid]", "[-i ip]", "[-p port]", "[-t template]",
	    "hostname");
	exit(1);
}

static int
addinterface(struct zrpc *rpc, char *ip, char *dns, char *port)
{
	if (zrpcaddarray(rpc, "interfaces") == -1)
		return -1;
	if (zrpcaddobj(rpc, NULL) == -1)
		return -1;
	if (zrpcaddint(rpc, "type", 1) == -1)
		return -1;
	if (zrpcaddint(rpc, "main", 1) == -1)
		return -1;
	if (zrpcaddint(rpc, "useip", 1) == -1)
		return -1;
	if (zrpcaddstr(rpc, "ip", ip) == -1)
		return -1;

	if (dns) {
		if (zrpcaddstr(rpc, "dns", dns) == -1)
			return -1;
	} else
		if (zrpcaddstr(rpc, "dns", "") == -1)
			return -1;

	if (zrpcaddstr(rpc, "port", port) == -1)
		return -1;
	if (zrpccloseobj(rpc) == -1)
		return -1;
	if (zrpcclosearray(rpc) == -1)
		return -1;

	return 0;
}

static int
addgroups(struct zrpc *rpc, char **grps)
{
	char **np;

	if (zrpcaddarray(rpc, "groups") == -1)
		return -1;

	np = grps;
	while (*np != NULL) {
		if (zrpcaddobj(rpc, NULL) == -1)
			return -1;
		if (zrpcaddstr(rpc, "groupid", *np) == -1)
			return -1;
		if (zrpccloseobj(rpc) == -1)
			return -1;
		np++;
	}

	if (zrpcclosearray(rpc) == -1)
		return -1;

	return 0;
}

static int
addtemplates(struct zrpc *rpc, char **tmpl)
{
	char **np;

	if (zrpcaddarray(rpc, "templates") == -1)
		return -1;

	np = tmpl;
	while (*np != NULL) {
		if (zrpcaddobj(rpc, NULL) == -1)
			return -1;
		if (zrpcaddstr(rpc, "templateid", *np) == -1)
			return -1;
		if (zrpccloseobj(rpc) == -1)
			return -1;
		np++;
	}

	if (zrpcclosearray(rpc) == -1)
		return -1;

	return 0;
}
