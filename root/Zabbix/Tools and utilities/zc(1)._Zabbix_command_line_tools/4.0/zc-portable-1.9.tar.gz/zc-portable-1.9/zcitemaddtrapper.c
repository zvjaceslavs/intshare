/* $Id: zcitemaddtrapper.c,v 1.3 2020/12/28 09:57:18 absc Exp $ */
/*
 * Copyright (c) 2019 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>

#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

extern struct valtype vtypes[];

static __dead void	usage(void);
static int		addapp(struct zrpc *, char **);

int
main(int argc, char *argv[])
{
	struct jsonv	val;
	struct zrpc	*rpc;
	char		fp[PATH_MAX];
	char		url[URLLEN], tok[TOKLEN];
	char		*app[ARRLEN], **np;
	char		*error, *hs, *nm, *hist, *trn;
	struct valtype	*tp;
	int		c, s;
	enum types	vt;

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "r") == -1)
		err(1, "%s", "unveil");

	if (pledge("dns rpath stdio inet", NULL) == -1)
		err(1, "%s", "pledge");

	*app = NULL;
	tp = NULL;
	hs = nm = NULL;
	vt = VNUM;
	hist = "90d";
	trn = "365d";
	np = app;

	while ((c = getopt(argc, argv, "a:h:n:r:s:t:")) != -1)
		switch (c) {
		case 'a':
			if (np == app + ARRLEN)
				errx(1, "too many applications specified");
			*np = optarg;
			np++;
			*np = NULL;
			break;
		case 'h':
			hs = optarg;
			break;
		case 'n':
			nm = optarg;
			break;
		case 'r':
			trn = optarg;
			break;
		case 's':
			hist = optarg;
			break;
		case 't':
			for (tp = vtypes; tp->type != VERR; tp++)
				if (strcmp(tp->key, optarg) == 0)
					vt = tp->type;
			if (!tp)
				errx(1, "%s", "bad data type specified");
			break;
		case '?':
			usage();
		}
	if (!hs)
		errx(1, "no host provided");
	if (!nm)
		errx(1, "no item name provided");

	argc -= optind;
	argv += optind;
	if (argc == 0)
		errx(1, "no key provided");

	if (getauthinfo(url, tok, NULL) == -1)
		err(1, "%s", fp);

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	rpc = zrpcinit(url, "item.create", tok, NULL);
	if (!rpc)
		errx(2, "%s", "failed to initialized rpc structure");

	if (zrpcaddobj(rpc, "params") == -1)
		errx(2, "%s", "error while adding \"params\" object");
	if (zrpcaddstr(rpc, "key_", *argv) == -1)
		errx(2, "%s", "error while adding \"key_\" object");
	if (zrpcaddstr(rpc, "name", nm) == -1)
		errx(2, "%s", "error while adding \"name\" object");
	if (zrpcaddint(rpc, "type", ITMTRP) == -1)
		errx(2, "%s", "error while adding \"type\" object");
	if (zrpcaddstr(rpc, "hostid", hs) == -1)
		errx(2, "%s", "error while adding \"hostid\" object");
	if (zrpcaddint(rpc, "value_type", vt) == -1)
		errx(2, "%s", "error while adding \"value_type\" object");
	if (zrpcaddstr(rpc, "history", hist) == -1)
		errx(2, "%s", "error while adding \"history\" object");
	if (zrpcaddstr(rpc, "trends", trn) == -1)
		errx(2, "%s", "error while adding \"trends\" object");
	if (addapp(rpc, app) == -1)
		errx(2, "%s", "error while adding applications");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing object");
	if (zrpcclose(rpc) == -1)
		errx(2, "%s", "error while closing payload");

	if (zrpcdo(rpc) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("stdio", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL &&
		    val.type != JSONV_ARR)
			continue;
		if (val.type == JSONV_ARR) {
			for (s = val.size; s > 0; s--) {
				if (zrpcjsonnext(rpc, &val) == -1)
					return 3;
				printf("%s\n", val.str);
			}
		} else if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
	}

	return 0;
}

static __dead void
usage(void)
{
	fprintf(stderr, "%s: %s %s %s %s %s %s %s %s\n", "usage",
	    getprogname(), "[-a application]", "[-r trends]",
	    "[-s history]", "[-t type]", "[-h hostid]", "[-n name]", "key");
	exit(1);
}

static int
addapp(struct zrpc *rpc, char **a)
{
	char	**np;

	if (!*a)
		return 0;

	if (zrpcaddarray(rpc, "applications") == -1)
		return -1;

	for (np = a; *np; np++)
		if (zrpcaddstr(rpc, NULL, *np) == -1)
			return -1;

	if (zrpcclosearray(rpc) == -1)
		return -1;

	return 0;
}
