/* $Id: compat.h,v 1.12 2020/03/05 21:02:55 absc Exp $ */
/*
 * Copyright (c) 2020 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef _COMPAT_H_
#define _COMPAT_H_

#ifndef _HAVE_PLEDGE_
int	pledge(const char *, const char *);
#endif /* _HAVE_PLEDGE */

#ifndef _HAVE_UNVEIL_
int	unveil(const char *, const char *);
#endif /* _HAVE_UNVEIL_ */

#ifndef _HAVE_STRLCPY_
size_t	strlcpy(char *, const char *, size_t);
#endif /* _HAVE_STRLCPY_ */

#ifndef _HAVE_STRTONUM_
long long	strtonum(const char *, long long, long long, const char **);
#endif /* _HAVE_STRTONUM_ */

#ifndef _HAVE_DEAD_
#define __dead
#endif /* _HAVE_DEAD_ */

#ifndef _HAVE_GETPROGNAME_
const char *	getprogname(void);
#endif /* _HAVE_GETPROGNAME */

#ifndef _HAVE_REALLOCARRAY_
void	*reallocarray(void *, size_t, size_t);
#endif /* _HAVE_REALLOCARRAY_ */

#ifndef _HAVE_EXPLICIT_BZERO_
__attribute__((weak)) void	__explicit_bzero_hook(void *, size_t);
void	explicit_bzero(void *, size_t);
#endif /* _HAVE_EXPLICIT_BZERO */

#ifdef _POSIX_GETOPT_
#define getopt(argc, argv, argstr)	getopt(argc, argv, "+"argstr)
#endif /* _POSIX_GETOPT_ */

#ifndef _HAVE_EXECVPE_
int	execvpe(const char *, char * const *, char * const *);
#endif /* _HAVE_EXECVPE */

#endif /* _COMPAT_H_ */
