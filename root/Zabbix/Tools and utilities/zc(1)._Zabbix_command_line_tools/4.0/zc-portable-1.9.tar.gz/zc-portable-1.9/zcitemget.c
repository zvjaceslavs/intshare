/* $Id: zcitemget.c,v 1.3 2020/12/28 09:57:18 absc Exp $ */
/*
 * Copyright (c) 2018 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>

#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

static __dead void	usage(void);

int
main(int argc, char *argv[])
{
	struct jsonv	val;
	struct zrpc	*rpc;
	char		fp[PATH_MAX];
	char		url[URLLEN], tok[TOKLEN];
	char		*app, *error, *host;
	int		c;

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "r") == -1)
		err(1, "%s", "unveil");

	if (pledge("dns rpath stdio inet", NULL) == -1)
		err(1, "%s", "pledge");

	app = host = NULL;
	while ((c = getopt(argc, argv, "a:h:")) != -1)
		switch (c) {
		case 'a':
			app = optarg;
			break;
		case 'h':
			host = optarg;
			break;
		case '?':
			usage();
		}
	argv += optind;

	if (getauthinfo(url, tok, NULL) == -1)
		err(1, "%s", fp);

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	rpc = zrpcinit(url, "item.get", tok, NULL);
	if (!rpc)
		errx(2, "%s", "failed to initialized rpc structure");

	if (zrpcaddobj(rpc, "params") == -1)
		errx(2, "%s", "error while adding \"params\" object");
	if (zrpcaddarray(rpc, "output") == -1)
		errx(2, "%s", "error while adding \"output\" object");
	if (zrpcaddstr(rpc, NULL, "itemid") == -1)
		errx(2, "%s", "error while adding \"itemid\" string");
	if (zrpcaddstr(rpc, NULL, "hostid") == -1)
		errx(2, "%s", "error while adding \"hostid\" string");
	if (zrpcaddstr(rpc, NULL, "delay") == -1)
		errx(2, "%s", "error while adding \"delay\" string");
	if (zrpcaddstr(rpc, NULL, "key_") == -1)
		errx(2, "%s", "error while adding \"key_\" string");
	if (zrpcaddstr(rpc, NULL, "name") == -1)
		errx(2, "%s", "error while adding \"name\" string");
	if (zrpcclosearray(rpc) == -1)
		errx(2, "%s", "error while closing array");
	if (*argv) {
		if (zrpcaddobj(rpc, "search") == -1)
			errx(2, "%s", "error while adding \"search\" object");
		if (zrpcaddstr(rpc, "name", *argv) == -1)
			errx(2, "%s", "error while adding \"name\" string");
		if (zrpccloseobj(rpc) == -1)
			errx(2, "%s", "error while closing object");
	}
	if (app)
		if (zrpcaddstr(rpc, "application", app) == -1)
			errx(2, "%s", "error while adding applications");
	if (host)
		if (zrpcaddstr(rpc, "host", host) == -1)
			errx(2, "%s", "error while adding host");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing object");
	if (zrpcclose(rpc) == -1)
		errx(2, "%s", "error while closing payload");

	if (zrpcdo(rpc) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("stdio", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL)
			continue;
		if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
		else if (strcmp(val.str, "itemid") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "hostid") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "delay") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "key_") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "name") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\n", val.str);
		}
	}

	return 0;
}

static __dead void
usage(void)
{
	fprintf(stderr, "%s: %s %s %s %s\n", "usage", getprogname(), "[-a application]",
	    "[-h host]", "[name]");
	exit(1);
}
