/* $Id: zceventget.c,v 1.3 2020/12/28 09:57:18 absc Exp $ */
/*
 * Copyright (c) 2019 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>
#include <sys/types.h>

#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

static __dead void	usage(void);

int
main(int argc, char *argv[])
{
	extern struct evobj	evobjects[];
	extern struct evsrc	sources[];
	extern struct evstate	evstates[];
	struct tm		sts, ets;
	struct jsonv	val;
	struct evobj	*obj;
	struct evsrc	*src;
	struct evstate	*state;
	char		fp[PATH_MAX];
	char		url[URLLEN], tok[TOKLEN];
	char		*error;
	const char		*ce;
	time_t		st, et;
	struct zrpc	*rpc;
	long long		v, co;
	int		c;

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "r") == -1)
		err(1, "%s", "unveil");

	if (pledge("dns rpath stdio inet", NULL) == -1)
		err(1, "%s", "pledge");

	st = et = 0;
	obj = NULL;
	src = NULL;
	co = EVOBJERR;
	while ((c = getopt(argc, argv, "b:e:o:s:")) != -1)
		switch (c) {
		case 'b':
			explicit_bzero(&sts, sizeof(sts));
			if (!strptime(optarg, "%FT%T", &sts))
				errx(1, "%s: %s", optarg, "bad value");
			st = mktime(&sts);
			if (st == -1)
				errx(1, "%s: %s", optarg, "bad value");
			break;
		case 'e':
			explicit_bzero(&ets, sizeof(ets));
			if (!strptime(optarg, "%FT%T", &ets))
				errx(1, "%s: %s", optarg, "bad value");
			et = mktime(&ets);
			if (et == -1)
				errx(1, "%s: %s", optarg, "bad value");
			break;
		case 'o':
			for (obj = evobjects; obj->type != EVOBJERR; obj++) {
				if (strcmp(optarg, obj->key) == 0)
					break;
			}
			if (obj->type == EVOBJERR)
				errx(1, "%s: %s", optarg,
				    "not a valid object type");
			break;
		case 's':
			for (src = sources; src->source != EVTERR; src++) {
				if (strcmp(optarg, src->key) == 0)
					break;
			}
			if (src->source == EVTERR)
				errx(1, "%s: %s", optarg,
				    "not a valid source type");
			break;
		case '?':
			usage();
		}

	if (getauthinfo(url, tok, NULL) == -1)
		err(1, "%s", fp);

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	rpc = zrpcinit(url, "event.get", tok, NULL);
	if (!rpc)
		errx(2, "%s", "failed to initialized rpc structure");

	if (zrpcaddobj(rpc, "params") == -1)
		errx(2, "%s", "error while adding \"params\" object");
	if (zrpcaddarray(rpc, "output") == -1)
		errx(2, "%s", "error while adding \"output\" object");
	if (zrpcaddstr(rpc, NULL, "eventid") == -1)
		errx(2, "%s", "error while adding \"eventid\" string");
	if (zrpcaddstr(rpc, NULL, "clock") == -1)
		errx(2, "%s", "error while adding \"clock\" string");
	if (zrpcaddstr(rpc, NULL, "source") == -1)
		errx(2, "%s", "error while adding \"source\" string");
	if (zrpcaddstr(rpc, NULL, "object") == -1)
		errx(2, "%s", "error while adding \"object\" string");
	if (zrpcaddstr(rpc, NULL, "value") == -1)
		errx(2, "%s", "error while adding \"value\" string");
	if (zrpcaddstr(rpc, NULL, "name") == -1)
		errx(2, "%s", "error while adding \"name\" string");
	if (zrpcclosearray(rpc) == -1)
		errx(2, "%s", "error while closing array");

	if (st > 0)
		if (zrpcaddint(rpc, "time_from", st) == -1)
			errx(2, "%s", "error while adding \"time_from\" object");
	if (et > 0)
		if (zrpcaddint(rpc, "time_till", et) == -1)
			errx(2, "%s", "error while adding \"time_till\" object");

	if (src)
		if (zrpcaddint(rpc, "source", src->source) == -1)
			errx(2, "%s", "error while adding source");
	if (obj)
		if (zrpcaddint(rpc, "object", obj->type) == -1)
			errx(2, "%s", "error while adding object");

	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing object");
	if (zrpcclose(rpc) == -1)
		errx(2, "%s", "error while closing payload");

	if (zrpcdo(rpc) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("stdio", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL)
			continue;

		if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
		else if (strcmp(val.str, "eventid") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "clock") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "source") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			v = strtonum(val.str, 0, 4, &ce);
			if (ce)
				errx(1, "%s %s", "strtonum", ce);
			for (src = sources; src->source != EVTERR; src++) {
				if (src->source == v) {
					printf("%s\t", src->key);
					break;
				}
			}
			if (src->source == EVTERR)
				errx(1, "%s: %s", optarg,
				    "not a valid source type");
		} else if (strcmp(val.str, "object") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			v = strtonum(val.str, 0, 6, &ce);
			if (ce)
				errx(1, "%s %s", "strtonum", ce);
			co = v;
			for (obj = evobjects; obj->type != EVOBJERR; src++) {
				if (obj->type == v) {
					printf("%s\t", obj->key);
					break;
				}
			}
			if (obj->type == EVOBJERR)
				errx(1, "%s: %s", optarg,
				    "not a valid object type");
		} else if (strcmp(val.str, "value") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			v = strtonum(val.str, 0, 4, &ce);
			if (ce)
				errx(1, "%s %s", "strtonum", ce);
			for (state = evstates; state->state != 255; state++) {
				if (state->state == v) {
					if (co == EVOBJERR)
						errx(1, "%s",
						    "Invalid object type");
					else if (co == EVOBJTRG)
						printf("%s\t",
						    state->key[0]);
					else if (co == EVOBJDSCHOST)
						printf("%s\t",
						    state->key[1]);
					else
						printf("%s\t",
						    state->key[2]);

					break;
				}
			}
			if (state->state == 255)
				errx(1, "%s: %s", optarg,
				    "not a valid object state");
		} else if (strcmp(val.str, "name") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\n", val.str);
		}
	}

	return 0;
}

static __dead void
usage(void)
{
	fprintf(stderr, "%s: %s %s %s %s %s", "usage", getprogname(), "[-ars]",
	    "[-b timestamp]", "[-e timestamp]", "[-t tag]");
	exit(1);
}
