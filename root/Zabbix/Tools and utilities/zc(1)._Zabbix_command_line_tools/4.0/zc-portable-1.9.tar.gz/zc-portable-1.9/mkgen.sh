#!/bin/sh
# $Id: mkgen.sh,v 1.3 2020/03/05 21:02:55 absc Exp $

OS=$(uname)
MANDIR=/usr/local/man
TARGETS=$(egrep -v '^$|^#' targets.txt | tr '\n' ',' | sed 's/,$//')

m4 -DTARGETS="${TARGETS}" m4/Makefile.m4 | sed '/cd  \&\&/d' > Makefile

if [ "${OS}" == "OpenBSD" ]; then
	MACROS="-D_HAVE_PLEDGE_ -D_HAVE_UNVEIL_"
	MACROS="${MACROS} -D_HAVE_STRLCPY_ -D_HAVE_STRTONUM_"
	MACROS="${MACROS} -D_HAVE_DEAD_ -D_HAVE_GETPROGNAME_"
	MACROS="${MACROS} -D_HAVE_REALLOCARRAY_"
	MACROS="${MACROS} -D_HAVE_EXPLICIT_BZERO_"

	TARGETFILE='m4/Makefile_target.m4'
elif [ "${OS}" == "Linux" ]; then
	MACROS="-D_GNU_SOURCE -D_POSIX_GETOPT_"
	COMPATSRC="strlcpy.c,strtonum.c,getprogname.c"
	COMPATSRC="${COMPATSRC},reallocarray.c"
	COMPATSRC="${COMPATSRC},explicit_bzero.c"
	COMPATSRC="${COMPATSRC},pledge.c,unveil.c"

	TARGETFILE='m4/Makefile_target_linux.m4'
elif [ "${OS}" == "FreeBSD" ]; then
	MACROS="-D_HAVE_STRLCPY_ -D_HAVE_STRTONUM_"
	MACROS="${MACROS} -D_HAVE_GETPROGNAME_"
	MACROS="${MACROS} -D_HAVE_REALLOCARRAY_"
	MACROS="${MACROS} -D_HAVE_EXPLICIT_BZERO"
	COMPATSRC="pledge.c,unveil.c,execvpe.c"

	TARGETFILE="m4/Makefile_target.m4"
fi

egrep -v '#|^$' targets.txt | while read _target; do
	_srcs=$(grep 'SRCS' ${_target}/depends | cut -d':' -f 2 |
	    tr -s ' ' ',' | sed 's/^,//g')
	_man=$(grep 'MAN' ${_target}/depends | cut -d':' -f 2 |
	    tr -s ' ' ',' | sed 's/^,//g')
	_instdir=$(grep 'BINDIR' ${_target}/depends | cut -d':' -f 2 |
	    tr -s ' ' ',' | sed 's/^,//g')

	_srcs="${_srcs},${COMPATSRC}"

	m4 -DTARGET="${_target}" -DINSTDIR="${_instdir}" \
	    -DMDIR="${MANDIR}"  -DSRCS="${_srcs}" -DMAN="${_man}" \
	    -DMACROS="${MACROS}" \
	    ${TARGETFILE} > ${_target}/Makefile
done
