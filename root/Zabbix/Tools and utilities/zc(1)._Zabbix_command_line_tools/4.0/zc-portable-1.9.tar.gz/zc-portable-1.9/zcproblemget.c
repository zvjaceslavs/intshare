/* $Id: zcproblemget.c,v 1.5 2020/12/28 09:57:18 absc Exp $ */
/*
 * Copyright (c) 2018 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>
#include <sys/types.h>

#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

static __dead void	usage(void);
static int		addtags(struct zrpc *, char **);

int
main(int argc, char *argv[])
{
	extern struct trigsev	severities[];
	struct trigsev	*sv;
	struct tm		sts, ets;
	struct jsonv	val;
	char		fp[PATH_MAX];
	char		url[URLLEN], tok[TOKLEN];
	char		*tag[ARRLEN], **tp;
	char		*error;
	time_t		st, et;
	struct zrpc	*rpc;
	enum severity	lv[SEVNUM],*sp;
	int		c;
	zrpcbool		ack, sup, rec;

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "r") == -1)
		err(1, "%s", "unveil");

	if (pledge("dns rpath stdio inet", NULL) == -1)
		err(1, "%s", "pledge");

	tp = tag;
	*tp = NULL;
	ack = sup = rec = ZRPCFALSE;
	st = et = 0;
	lv[0] = TRGERR;
	sp = lv;
	while ((c = getopt(argc, argv, "arsb:e:l:t:")) != -1)
		switch (c) {
		case 'a':
			ack = ZRPCTRUE;
			break;

		case 'r':
			rec = ZRPCTRUE;
			break;
		case 's':
			sup = ZRPCTRUE;
			break;
		case 'b':
			explicit_bzero(&sts, sizeof(sts));
			if (!strptime(optarg, "%FT%T", &sts))
				errx(1, "%s: %s", optarg, "bad value");
			st = mktime(&sts);
			if (st == -1)
				errx(1, "%s: %s", optarg, "bad value");
			break;
		case 'e':
			explicit_bzero(&ets, sizeof(ets));
			if (!strptime(optarg, "%FT%T", &ets))
				errx(1, "%s: %s", optarg, "bad value");
			et = mktime(&ets);
			if (et == -1)
				errx(1, "%s: %s", optarg, "bad value");
			break;
		case 'l':
			for (sv = severities; sv->sev != TRGERR; sv++) {
				if (sp == lv + SEVNUM)
					errx(1, "%s", "too many severities");
				if (strcmp(sv->key, optarg) == 0) {
					*sp++ = sv->sev;
					*sp = TRGERR;
					break;
				}
			}
			if (sv->sev == TRGERR)
				errx(1, "%s", "invalid severity");
			break;
		case 't':
			if (tp == tag + ARRLEN)
				errx(1, "too many tags.");
			*tp++ = optarg;
			*tp = NULL;
			break;
		case '?':
			usage();
		}

	if (getauthinfo(url, tok, NULL) == -1)
		err(1, "%s", fp);

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	rpc = zrpcinit(url, "problem.get", tok, NULL);
	if (!rpc)
		errx(2, "%s", "failed to initialized rpc structure");

	if (zrpcaddobj(rpc, "params") == -1)
		errx(2, "%s", "error while adding \"params\" object");
	if (zrpcaddarray(rpc, "output") == -1)
		errx(2, "%s", "error while adding \"output\" object");
	if (zrpcaddstr(rpc, NULL, "eventid") == -1)
		errx(2, "%s", "error while adding \"eventid\" string");
	if (zrpcaddstr(rpc, NULL, "clock") == -1)
		errx(2, "%s", "error while adding \"clock\" string");
	if (zrpcaddstr(rpc, NULL, "severity") == -1)
		errx(2, "%s", "error while adding \"severity\" string");
	if (zrpcaddstr(rpc, NULL, "name") == -1)
		errx(2, "%s", "error while adding \"name\" string");
	if (zrpcclosearray(rpc) == -1)
		errx(2, "%s", "error while closing array");

	if (st > 0)
		if (zrpcaddint(rpc, "time_from", st) == -1)
			errx(2, "%s", "error while adding \"time_from\" object");
	if (et > 0)
		if (zrpcaddint(rpc, "time_till", et) == -1)
			errx(2, "%s", "error while adding \"time_till\" object");

	if (lv[0] != TRGERR) {
		if (zrpcaddarray(rpc, "severities") == -1)
			errx(2, "%s", "error while adding \"severities\" object");
		for (sp = lv; *sp != TRGERR; sp++)
			zrpcaddint(rpc, NULL, *sp);
		if (zrpcclosearray(rpc) == -1)
			errx(2, "%s", "error while closing array");
	}

	if (zrpcaddbool(rpc, "acknowledged", ack) == -1)
		errx(2, "%s", "error while adding \"acknowledged\" object");
	if (zrpcaddbool(rpc, "suppressed", sup) == -1)
		errx(2, "%s", "error while adding \"suppressed\" object");
	if (zrpcaddbool(rpc, "recent", rec) == -1)
		errx(2, "%s", "error while adding \"recent\" object");

	if (addtags(rpc, tag) == -1)
		errx(2, "%s", "error while adding tags");

	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing object");
	if (zrpcclose(rpc) == -1)
		errx(2, "%s", "error while closing payload");

	if (zrpcdo(rpc) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("stdio", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL)
			continue;
		if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
		else if (strcmp(val.str, "eventid") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "clock") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "severity") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			for (sv = severities; sv->sev != TRGERR; sv++)
				if (atoi(val.str) == (int)sv->sev)
					printf("%s\t", sv->key);
		} else if (strcmp(val.str, "name") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\n", val.str);
		}
	}

	return 0;
}

static __dead void
usage(void)
{
	fprintf(stderr, "%s: %s %s %s %s %s\n", "usage", getprogname(), "[-ars]",
	    "[-b timestamp]", "[-e timestamp]", "[-t tag]");
	exit(1);
}

static int
addtags(struct zrpc *rpc, char **tags)
{
	char	**np, *tag, *val;

	if (zrpcaddarray(rpc, "tags") == -1)
		return -1;

	for (np = tags; *np; np++) {
		val = *np;
		tag = strsep(&val, "=");
		if (zrpcaddobj(rpc, NULL) == -1)
			return -1;
		if (zrpcaddstr(rpc, "tag", tag) == -1)
			return -1;
		if (val)
			if (zrpcaddstr(rpc, "value", val) == -1)
				return -1;
		if (zrpccloseobj(rpc) == -1)
			return -1;
	}

	if (zrpcclosearray(rpc) == -1)
		return -1;

	return 0;
}
