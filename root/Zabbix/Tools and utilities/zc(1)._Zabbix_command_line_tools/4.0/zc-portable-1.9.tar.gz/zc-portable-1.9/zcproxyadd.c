/* $Id: zcproxyadd.c,v 1.5 2020/12/28 09:57:18 absc Exp $ */
/*
 * Copyright (c) 2020 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>

#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

static __dead void	usage(void);

int
main(int argc, char *argv[])
{
	struct jsonv	val;
	struct zrpc	*rpc;
	char		*dsc, *pn, *error;
	char		fp[PATH_MAX];
	char		url[URLLEN], tok[TOKLEN];
	int		c, s;

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "r") == -1)
		err(1, "%s", "unveil");

	if (pledge("dns rpath stdio inet", NULL) == -1)
		err(1, "%s", "pledge");

	dsc = NULL;
	while ((c = getopt(argc, argv, "d:")) != -1)
		switch (c) {
		case 'd':
			dsc = optarg;
			break;
		case '?':
			usage();
		}
	argc -= optind;
	argv += optind;

	if (argc == 0)
		errx(1, "%s", "missing proxy name");

	pn = *argv;

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	if (getauthinfo(url, tok, NULL) == -1)
		err(1, "%s", fp);

	rpc = zrpcinit(url, "proxy.create", tok, NULL);
	if (!rpc)
		errx(2, "%s", "failed to initialized rpc structure");

	if (zrpcaddobj(rpc, "params") == -1)
		errx(2, "%s", "error while adding \"params\" object");

	if (zrpcaddstr(rpc, "host", pn) == -1)
		errx(2, "%s", "error while adding \"host\" object");
	if (zrpcaddstr(rpc, "status", "5") == -1)
		errx(2, "%s", "error while adding \"status\" object");

	if (dsc)
		if (zrpcaddstr(rpc, "description", dsc) == -1)
			errx(2, "%s", "error while adding \"description\" object");

	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing the object");
	if (zrpcclose(rpc) == -1)
		errx(2, "%s", "error while closing payload");

	if (zrpcdo(rpc) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("stdio", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL &&
		    val.type != JSONV_ARR)
			continue;
		if (val.type == JSONV_ARR) {
			for (s = val.size; s > 0; s--) {
				if (zrpcjsonnext(rpc, &val) == -1)
					return 3;
				printf("%s\n", val.str);
			}
		} else if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
	}

	return 0;
}

static __dead void
usage(void)
{
	fprintf(stderr, "%s: %s %s %s\n", "usage", getprogname(),
	    "[-d description]", "name");
	exit(1);
}
