/* $Id: zcconfigimport.c,v 1.3 2020/12/28 09:57:18 absc Exp $ */
/*
 * Copyright (c) 2019 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>

#include <err.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

#define BS	1024

static __dead void	usage(void);

int
main(int argc, char *argv[])
{
	struct jsonv	val;
	char		fp[PATH_MAX];
	char		url[URLLEN], tok[TOKLEN], *error, *data, *tdata, *bp;
	ssize_t		ts, cs, off;
	struct zrpc	*rpc;
	zrpcbool		cm, dm, ue;
	int		c, fd;

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "r") == -1)
		err(1, "%s", "unveil");

	if (pledge("dns rpath stdio inet unveil", NULL) == -1)
		err(1, "%s", "pledge");

	cm = dm = ue = ZRPCFALSE;

	while ((c = getopt(argc, argv, "cdu")) != -1)
		switch (c) {
		case 'c':
			cm = ZRPCTRUE;
			break;
		case 'd':
			dm = ZRPCTRUE;
			break;
		case 'u':
			ue = ZRPCTRUE;
			break;
		case '?':
			usage();
		}
	argc -= optind;
	argv += optind;

	if (argc > 0) {
		if (unveil(argv[0], "r") == -1)
			err(1, "%s", "unveil");
		fd = open(argv[0], O_RDONLY);
		if (fd == -1)
			err(2, "%s", "open");
	} else {
		fd = STDIN_FILENO;
	}

	if (pledge("dns rpath stdio inet", NULL) == -1)
		err(1, "%s", "pledge");

	if (getauthinfo(url, tok, NULL) == -1)
		err(1, "%s", fp);

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	rpc = zrpcinit(url, "configuration.import", tok, NULL);
	if (!rpc)
		errx(2, "%s", "failed to initialized rpc structure");

	if (zrpcaddobj(rpc, "params") == -1)
		errx(2, "%s", "error while adding \"params\" object");
	if (zrpcaddstr(rpc, "format", "json") == -1)
		errx(2, "%s", "error while adding \"format\" string");
	if (zrpcaddobj(rpc, "rules") == -1)
		errx(2, "%s", "error while adding \"rules\" object");

	if (zrpcaddobj(rpc, "applications") == -1)
		errx(2, "%s", "error while adding \"applications\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" application bool");
	if (zrpcaddbool(rpc, "deleteMissing", dm) == -1)
		errx(2, "%s", "error while adding \"deleteMissing\" application bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"applications\" object");

	if (zrpcaddobj(rpc, "discoveryRules") == -1)
		errx(2, "%s", "error while adding \"discoveryRules\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" discoveryRules bool");
	if (zrpcaddbool(rpc, "updateExisting", ue) == -1)
		errx(2, "%s", "error while adding \"updateExisting\" discoveryRules bool");
	if (zrpcaddbool(rpc, "deleteMissing", ue) == -1)
		errx(2, "%s", "error while adding \"deleteMissing\" discoveryRules bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"discoveryRules\" object");

	if (zrpcaddobj(rpc, "graphs") == -1)
		errx(2, "%s", "error while adding \"graphs\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" graphs bool");
	if (zrpcaddbool(rpc, "updateExisting", ue) == -1)
		errx(2, "%s", "error while adding \"updateExisting\" graphs bool");
	if (zrpcaddbool(rpc, "deleteMissing", ue) == -1)
		errx(2, "%s", "error while adding \"deleteMissing\" graphs bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"graphs\" object");

	if (zrpcaddobj(rpc, "groups") == -1)
		errx(2, "%s", "error while adding \"groups\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" groups bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"groups\" object");

	if (zrpcaddobj(rpc, "hosts") == -1)
		errx(2, "%s", "error while adding \"hosts\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" hosts bool");
	if (zrpcaddbool(rpc, "updateExisting", ue) == -1)
		errx(2, "%s", "error while adding \"updateExisting\" hosts bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"hosts\" object");

	if (zrpcaddobj(rpc, "httptests") == -1)
		errx(2, "%s", "error while adding \"httptests\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" httptests bool");
	if (zrpcaddbool(rpc, "updateExisting", ue) == -1)
		errx(2, "%s", "error while adding \"updateExisting\" httptests bool");
	if (zrpcaddbool(rpc, "deleteMissing", ue) == -1)
		errx(2, "%s", "error while adding \"deleteMissing\" httptests bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"httptests\" object");

	if (zrpcaddobj(rpc, "images") == -1)
		errx(2, "%s", "error while adding \"images\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" images bool");
	if (zrpcaddbool(rpc, "updateExisting", ue) == -1)
		errx(2, "%s", "error while adding \"updateExisting\" images bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"images\" object");

	if (zrpcaddobj(rpc, "items") == -1)
		errx(2, "%s", "error while adding \"items\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" items bool");
	if (zrpcaddbool(rpc, "updateExisting", ue) == -1)
		errx(2, "%s", "error while adding \"updateExisting\" items bool");
	if (zrpcaddbool(rpc, "deleteMissing", ue) == -1)
		errx(2, "%s", "error while adding \"deleteMissing\" items bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"items\" object");

	if (zrpcaddobj(rpc, "maps") == -1)
		errx(2, "%s", "error while adding \"maps\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" maps bool");
	if (zrpcaddbool(rpc, "updateExisting", ue) == -1)
		errx(2, "%s", "error while adding \"updateExisting\" maps bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"maps\" object");

	if (zrpcaddobj(rpc, "templateLinkage") == -1)
		errx(2, "%s", "error while adding \"templateLinkage\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" templateLinkage bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"templateLinkage\" object");

	if (zrpcaddobj(rpc, "templates") == -1)
		errx(2, "%s", "error while adding \"templates\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" templates bool");
	if (zrpcaddbool(rpc, "updateExisting", ue) == -1)
		errx(2, "%s", "error while adding \"updateExisting\" templates bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"templates\" object");

	if (zrpcaddobj(rpc, "templateScreens") == -1)
		errx(2, "%s", "error while adding \"templateScreens\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" templateScreens bool");
	if (zrpcaddbool(rpc, "updateExisting", ue) == -1)
		errx(2, "%s", "error while adding \"updateExisting\" templateScreens bool");
	if (zrpcaddbool(rpc, "deleteMissing", ue) == -1)
		errx(2, "%s", "error while adding \"deleteMissing\" templateScreens bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"templateScreens\" object");

	if (zrpcaddobj(rpc, "triggers") == -1)
		errx(2, "%s", "error while adding \"triggers\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" triggers bool");
	if (zrpcaddbool(rpc, "updateExisting", ue) == -1)
		errx(2, "%s", "error while adding \"updateExisting\" triggers bool");
	if (zrpcaddbool(rpc, "deleteMissing", ue) == -1)
		errx(2, "%s", "error while adding \"deleteMissing\" triggers bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"triggers\" object");

	if (zrpcaddobj(rpc, "valueMaps") == -1)
		errx(2, "%s", "error while adding \"valueMaps\" object");
	if (zrpcaddbool(rpc, "createMissing", cm) == -1)
		errx(2, "%s", "error while adding \"createMissing\" valueMaps bool");
	if (zrpcaddbool(rpc, "updateExisting", ue) == -1)
		errx(2, "%s", "error while adding \"updateExisting\" valueMaps bool");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"valueMaps\" object");

	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing \"rules\" object");

	ts = cs = off = 0;
	data = NULL;
	do {
		if (ts - (off + cs) < BS) {
			ts = ts == 0 ? BS : ts * 2;
			tdata = reallocarray(data, ts, sizeof(char));
			if (!tdata)
				err(2, "%s", "reallocarray");
			data = bp = tdata;
			bp += off;
		}
		bp += cs;
		off += cs;
		cs = read(fd, bp, ts - off);
	} while (cs != 0 && cs != -1);

	if (cs == -1)
		err(1, "%s", "read");

	bp[0] = '\0';

	if (zrpcaddstr(rpc, "source", data) == -1)
		errx(2, "%s", "error while adding \"source\" payload");

	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing object");
	if (zrpcclose(rpc) == -1)
		errx(2, "%s", "error while closing json");

	if (zrpcdo(rpc) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("stdio", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL)
			continue;
		if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
	}

	return 0;
}

static __dead void
usage(void)
{
	fprintf(stderr, "%s: %s %s %s\n", "usage", getprogname(), "[-cdu]", "[file]");
	exit(1);
}
