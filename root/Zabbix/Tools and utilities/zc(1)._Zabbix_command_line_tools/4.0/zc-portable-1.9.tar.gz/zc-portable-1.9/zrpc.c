/* $Id: zrpc.c,v 1.8 2020/12/29 20:38:47 absc Exp $ */
/*
 * Copyright (c) 2018, 2019 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <assert.h>
#include <math.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <curl/curl.h>

#include "compat.h"

#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

#define BLEN	2048

struct valtype vtypes[] = {
	{VFLOAT, "float"},
	{VCHAR, "char"},
	{VLOG, "log"},
	{VNUM, "num"},
	{VTEXT, "text"},
	{VERR, NULL}
};

struct itemtype itmtypes[] = {
	{ITMPSV, "passive"},
	{ITMSNMPV1, "snmpv1"},
	{ITMTRP, "trapper"},
	{ITMSMPL, "simple"},
	{ITMSNMPV2, "snmpv2"},
	{ITMITRN, "internal"},
	{ITMSNMPV3, "snmpv2"},
	{ITMACT, "active"},
	{ITMAGG, "aggregate"},
	{ITMWEB, "web"},
	{ITMEXT, "external"},
	{ITMDB, "database"},
	{ITMIPMI, "ipmi"},
	{ITMSSH, "ssh"},
	{ITMTLNT, "telnet"},
	{ITMCALC, "calculated"},
	{ITMJMX, "jmx"},
	{ITMSNMPT, "snmptrap"},
	{ITMDEP, "dependent"},
	{ITMHTTP, "http"},
	{ITMERR, NULL}
};

struct trigsev severities[] = {
	{TRGNC, "nc"},
	{TRGINF, "info"},
	{TRGWARN, "warn"},
	{TRGAVG, "avg"},
	{TRGHIGH, "high"},
	{TRGDIS, "dis"},
	{TRGERR, NULL}
};

struct authproto authprotos[] = {
	{APMD5, "md5"},
	{APSHA, "sha"},
	{APERR, NULL}
};

struct privproto privprotos[] = {
	{PPROTODES, "des"},
	{PPROTOAES, "aes"},
	{PPROTOERR, NULL}
};

struct iface ifaces[] = {
	{IFAGENT, "agent"},
	{IFSNMP, "snmp"},
	{IFIPMI, "ipmi"},
	{IFJMX, "jmx"},
	{IFERR, NULL}
};

struct snmp snmps[] = {
	{SNMPv1, "1"},
	{SNMPv2c, "2c"},
	{SNMPv3, "3"},
	{SNMPERR, NULL},
};

struct evsrc sources[] = {
	{EVTTRG, "trigger"},
	{EVTDSC, "discovery"},
	{EVTAUTOR, "autoreg"},
	{EVTINTR, "internal"},
	{EVTERR, NULL}
};

struct evobj evobjects[] = {
	{EVOBJTRG, "trigger"},
	{EVOBJDSCHOST, "dhost"},
	{EVOBJDSCSRV, "dservice"},
	{EVOBJAUTOREG, "autoreg"},
	{EVOBJITM, "item"},
	{EVOBJLLD, "lld"},
	{EVOBJERR, NULL}
};

struct seclevel seclevels[] = {
	{SLNOAUTHNOPRIV, "nanp"},
	{SLAUTHNOPRIV, "anp"},
	{SLAUTHPRIV, "ap"},
	{SLERR, NULL}
};

struct evstate evstates[] = {
	{0, {"ok", "up", "normal"}},
	{1, {"problem", "down", "unknown"}},
	{2, {NULL, "discovered", NULL}},
	{3, {NULL, "lost", NULL}},
	{255, {NULL, NULL, NULL}}
};

static int		growbuf(struct zrpc *, size_t);
static size_t	rpcwrite(char *, size_t, size_t, void *);
static int		jsoninit(struct zrpc *);

int
zrpcglobalinit(char **error)
{
	CURLcode	e;

	if ((e = curl_global_init(CURL_GLOBAL_ALL)) != CURLE_OK) {
		*error = strdup(curl_easy_strerror(e));
		return -1;
	}

	return 0;
}

struct zrpc *
zrpcinit(const char *url, const char *m, const char *t, streamcb cb)
{
	struct zrpc	*rpc;

	if (!url || !m)
		return NULL;

	rpc = calloc(1, sizeof(struct zrpc));
	if (!rpc)
		return NULL;

	rpc->b = malloc(BLEN * sizeof(char));
	if (!rpc->b) {
		zrpcfree(rpc);
		return NULL;
	}
	rpc->bs = BLEN;

	rpc->hnd = curl_easy_init();
	if (!rpc->hnd) {
		zrpcfree(rpc);
		return NULL;
	}

	if (strlcpy(rpc->url, url, URLLEN) >= URLLEN) {
		zrpcfree(rpc);
		return NULL;
	}

	rpc->hdr = curl_slist_append(rpc->hdr, "Content-Type: application/json-rpc");

	curl_easy_setopt(rpc->hnd, CURLOPT_URL, rpc->url);
	curl_easy_setopt(rpc->hnd, CURLOPT_HTTPHEADER, rpc->hdr);
	curl_easy_setopt(rpc->hnd, CURLOPT_WRITEDATA, rpc);
	curl_easy_setopt(rpc->hnd, CURLOPT_WRITEFUNCTION, cb != NULL ?
	    cb : rpcwrite);

	rpc->b[0] = '{';
	rpc->b[1] = '\0';
	rpc->np = rpc->b + 1;
	rpc->s = 1;

	if (zrpcaddstr(rpc, "jsonrpc", "2.0") == -1) {
		zrpcfree(rpc);
		return NULL;
	}
	if (zrpcaddint(rpc, "id", 1) == -1) {
		zrpcfree(rpc);
		return NULL;
	}
	if (zrpcaddstr(rpc, "method", m) == -1) {
		zrpcfree(rpc);
		return NULL;
	}

	if (t == NULL) {
		if (zrpcaddnull(rpc, "auth") == -1) {
			zrpcfree(rpc);
			return NULL;
		}
	} else {
		if (zrpcaddstr(rpc, "auth", t) == -1) {
			zrpcfree(rpc);
			return NULL;
		}
	}

	return rpc;
}

void
zrpcfree(struct zrpc *rpc)
{
	curl_slist_free_all(rpc->hdr);
	curl_easy_cleanup(rpc->hnd);
	curl_global_cleanup();

	free(rpc->b);
	free(rpc->tk);
	free(rpc);
}

int
zrpcaddstr(struct zrpc *rpc, const char *n, const char *v)
{
	size_t	l, s;

	/*
	 * We assume the string is properly terminated with '\0'.
	 * Be sure to terminate the array before passing it to the
	 * function.
	 */

	if (!rpc || !v)
		return -1;

	l = strlen(v);

	/*
	 * We need to have enough space for 4 more characters
	 * in the buffer out of the string size we calculated.
	 */
	if (growbuf(rpc, l + 4) == -1)
		return -1;

	rpc->np[0] = '"';
	rpc->np++;
	rpc->s++;

	if (n) {
		s = snprintf(rpc->np, rpc->bs - rpc->s, "%s\":\"", n);
		if (s >= rpc->bs - rpc->s)
			return -1;

		rpc->s += s;
		rpc->np += s;
	}

	if ((s = strlcpy(rpc->np, v, rpc->bs - rpc->s)) >= rpc->bs - rpc->s)
		return -1;

	rpc->np += s;
	rpc->np[0] = '"';
	rpc->np[1] = ',';
	rpc->np[2] = '\0';
	rpc->s += (s + 2);
	rpc->np += 2;

	return 0;
}

int
zrpcaddint(struct zrpc *rpc, const char *n, long long v)
{
	int	s;

	if (!rpc)
		return -1;

	if (growbuf(rpc, STRLEN) == -1)
		return -1;

	if (!n)
		s = snprintf(rpc->np, rpc->bs - rpc->s, "%lld,", v);
	else
		s = snprintf(rpc->np, rpc->bs - rpc->s, "\"%s\":%lld,", n, v);
	if (s >= STRLEN)
		return -1;

	rpc->s += s;
	rpc->np += s;

	return 0;
}

int
zrpcaddbool(struct zrpc *rpc, const char *n, zrpcbool v)
{
	int	s;

	if (!rpc)
		return -1;

	if (growbuf(rpc, STRLEN) == -1)
		return -1;

	if (!n)
		s = snprintf(rpc->np, rpc->bs - rpc->s, "%s,",
		    v == ZRPCFALSE ? "false" : "true");
	else
		s = snprintf(rpc->np, rpc->bs - rpc->s, "\"%s\":%s,", n,
		    v == ZRPCFALSE ? "false" : "true");
	if (s >= STRLEN)
		return -1;

	rpc->s += s;
	rpc->np += s;

	return 0;
}

int
zrpcaddobj(struct zrpc *rpc, const char *n)
{
	int	s;

	if (!rpc)
		return -1;

	if (growbuf(rpc, STRLEN) == -1)
		return -1;

	if (n)
		s = snprintf(rpc->np, rpc->bs - rpc->s, "\"%s\":{", n);
	else {
		s = snprintf(rpc->np, rpc->bs - rpc->s, "%s", "{");
	}
	if (s >= STRLEN)
		return -1;

	rpc->s += s;
	rpc->np += s;

	return 0;
}

int
zrpccloseobj(struct zrpc *rpc)
{
	if (zrpcclose(rpc) == -1)
		return -1;

	rpc->np[0] = ',';
	rpc->np[1] = '\0';
	rpc->np++;
	rpc->s++;

	return 0;
}

int
zrpcaddarray(struct zrpc *rpc, const char *n)
{
	int	s;

	if (!rpc)
		return -1;

	if (growbuf(rpc, STRLEN) == -1)
		return -1;

	if (n)
		s = snprintf(rpc->np, rpc->bs - rpc->s, "\"%s\":[", n);
	else
		s = snprintf(rpc->np, rpc->bs - rpc->s, "[");
	if (s >= STRLEN)
		return -1;

	rpc->s += s;
	rpc->np += s;

	return 0;
}

int
zrpcclosearray(struct zrpc *rpc)
{
	char	*p;

	if (!rpc)
		return -1;

	if (growbuf(rpc, STRLEN) == -1)
		return -1;

	p = rpc->np;
	if (p[-1] == ',') {
		p--;
		rpc->s--;
	}

	p[0] = ']';
	p[1] = ',';
	p[2] = '\0';
	p += 2;
	rpc->s += 2;
	rpc->np = p;

	return 0;
}

int
zrpcaddnull(struct zrpc *rpc, const char *n)
{
	int	s;

	if (!rpc || !n)
		return -1;

	if (growbuf(rpc, STRLEN) == -1)
		return -1;

	s = snprintf(rpc->np, rpc->bs - rpc->s, "\"%s\":%s,", n, "null");
	if (s >= STRLEN)
		return -1;

	rpc->s += s;
	rpc->np += s;

	return 0;
}

int
zrpcclose(struct zrpc *rpc)
{
	char	*p;

	if (!rpc)
		return -1;

	if (growbuf(rpc, STRLEN) == -1)
		return -1;

	p = rpc->np;
	if (p[-1] == ',') {
		p--;
		rpc->s--;
	}

	p[0] = '}';
	p[1] = '\0';
	p++;
	rpc->np = p;
	rpc->s++;

	return 0;
}

int
zrpcdo(struct zrpc *rpc)
{
	long	hs;
	CURLcode	e;

	if (!rpc)
		return -1;

	curl_easy_setopt(rpc->hnd, CURLOPT_POSTFIELDS, rpc->b);
	curl_easy_setopt(rpc->hnd, CURLOPT_POSTFIELDSIZE, rpc->s);

	rpc->np = rpc->b;
	rpc->s = 0;

	e = curl_easy_perform(rpc->hnd);
	if (e != CURLE_OK)
		if (strlcpy(rpc->b, curl_easy_strerror(e), rpc->bs) >= rpc->bs)
			return -1;

	e = curl_easy_getinfo(rpc->hnd, CURLINFO_RESPONSE_CODE, &hs);
	if (e != CURLE_OK)
		if (strlcpy(rpc->b, curl_easy_strerror(e), rpc->bs) >= rpc->bs)
			return -1;
	if (hs != 200)
		return -1;

	return 0;
}

static int
growbuf(struct zrpc *rpc, size_t psize)
{
	char	*p;

	while (rpc->bs - rpc->s <= psize) {
		p = reallocarray(rpc->b, rpc->bs * 2, sizeof(char));
		if (!p)
			return -1;
		rpc->b = p;

		rpc->np = rpc->b + rpc->s;
		rpc->bs = rpc->bs * 2;
	}

	assert(rpc->s + psize < rpc->bs);

	return 0;
}

static size_t
rpcwrite(char *p, size_t s, size_t n, void *ud)
{
	struct zrpc	*r;

	r = ud;
	if (growbuf(r, s * n) == -1)
		return 0;

	memcpy(r->np, p, n * s);

	r->s += s * n;
	r->np += n;
	r->np[0] = '\0';

	return n * s;
}

int
zrpcjsonnext(struct zrpc *rpc, struct jsonv *v)
{
	int	s, e;

	if (!rpc || !v)
		return -1;

	if (!rpc->tk) {
		if (jsoninit(rpc) == -1)
			return -1;
	} else {
		if (rpc->cp == rpc->tc)
			return -1;

		rpc->tk++;
		rpc->cp++;
	}

	v->str = NULL;

	switch (rpc->tk->type) {
	case JSMN_PRIMITIVE:
		v->type = JSONV_VAL;
		break;
	case JSMN_OBJECT:
		v->type = JSONV_OBJ;
		v->size = rpc->tk->size;
		return 0;
	case JSMN_ARRAY:
		v->type = JSONV_ARR;
		v->size = rpc->tk->size;
		return 0;
	case JSMN_STRING:
		v->type = JSONV_STR;
		break;
	default:
		return -1;
	}

	s = rpc->tk->start;
	e = rpc->tk->end;
	if (v->type == JSONV_STR || v->type == JSONV_VAL) {
		v->str = rpc->b + s;
		v->str[e - s] = '\0';
	}

	return 0;
}

char *
zrpcgeterror(struct zrpc *rpc)
{
	char		s[STRLEN];
	struct jsonv	v, c, m, d;

	s[0] = '\0';

	if (zrpcjsonnext(rpc, &v) == -1)
		return NULL;
	if (zrpcjsonnext(rpc, &v) == -1)
		return NULL;
	if (zrpcjsonnext(rpc, &c) == -1)
		return NULL;
	if (zrpcjsonnext(rpc, &v) == -1)
		return NULL;
	if (zrpcjsonnext(rpc, &m) == -1)
		return NULL;
	if (zrpcjsonnext(rpc, &v) == -1)
		return NULL;
	if (zrpcjsonnext(rpc, &d) == -1)
		return NULL;

	if (snprintf(s, STRLEN, "%s: %s %s", c.str, m.str, d.str) >= STRLEN)
		return NULL;

	return strdup(s);
}

static int
jsoninit(struct zrpc *rpc)
{
	jsmn_parser	jp;
	int		c;

	c = JTOKMIN;
	jsmn_init(&jp);

	do {
		rpc->tk = reallocarray(rpc->tk, c, sizeof(jsmntok_t));
		if (!rpc->tk)
			return -1;

		rpc->tc = jsmn_parse(&jp, rpc->b, rpc->s, rpc->tk, c);
		c *= 2;
	} while (rpc->tc == JSMN_ERROR_NOMEM);

	rpc->cp = 1;

	return rpc->tc;
}
