/* $Id: zctrigger.c,v 1.2 2020/02/09 21:34:03 absc Exp $ */
/*
 * Copyright (c) 2018 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>

#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "compat.h"

#include "pathnames.h"

struct cmd {
	char	*key;
	char	*cmd;
	char	*pname;
} cmds[] = {
	{"add", LIBEXEC"/zctriggeradd", "zc trigger add"},
	{"get", LIBEXEC"/zctriggerget", "zc trigger get"},
	{"rm", LIBEXEC"/zctriggerrm", "zc trigger rm"},
	{NULL, NULL, NULL}
};

static __dead void	usage(void);

int
main(int argc, char *argv[])
{
	struct cmd	*np;

	if (pledge("exec proc stdio", NULL) == -1)
		err(1, "%s", "pledge");

	if (argc == 1)
		usage();
	for (np = cmds; np->key != NULL; np++) {
		if (strcmp(argv[1], np->key) == 0)
			break;
	}
	argv++;

	if (np->key == NULL)
		usage();

	*argv = np->pname;
	if (execvp(np->cmd, argv) == -1)
		err(2, "execv");

	return 0;
}

static __dead void
usage(void)
{
	struct cmd	*np;

	fprintf(stderr, "%s:\n", "possibilities are");
	for (np = cmds; np->key != NULL; np++)
		fprintf(stderr, "%s\n", np->key);

	exit(1);
}
