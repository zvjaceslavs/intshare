/* $Id: zchostinterfaceget.c,v 1.4 2020/12/28 09:57:18 absc Exp $ */
/*
 * Copyright (c) 2019 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

int	addhosts(struct zrpc *, char **);

int
main(int argc, char *argv[])
{
	extern struct iface	ifaces[];
	char		fp[PATH_MAX];
	char		url[URLLEN], tok[TOKLEN];
	struct jsonv	val;
	struct iface	*ifp;
	struct zrpc	*rpc;
	char		*error;
	enum ifacetype	it;

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "r") == -1)
		err(1, "%s", "unveil");

	if (pledge("dns rpath stdio inet", NULL) == -1)
		err(1, "%s", "pledge");

	argc--;
	argv++;

	if (getauthinfo(url, tok, NULL) == -1)
		errx(1, "%s", fp);

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	rpc = zrpcinit(url, "hostinterface.get", tok, NULL);
	if (!rpc)
		errx(2, "%s", "failed to initialized rpc structure");

	if (zrpcaddobj(rpc, "params") == -1)
		errx(2, "%s", "error while adding \"params\" object");

	if (zrpcaddarray(rpc, "output") == -1)
		errx(2, "%s", "error while adding \"output\" object");
	if (zrpcaddstr(rpc, NULL, "interfaceid") == -1)
		errx(2, "%s", "error while adding \"interfaceid\"");
	if (zrpcaddstr(rpc, NULL, "hostid") == -1)
		errx(2, "%s", "error while adding \"hostid\"");
	if (zrpcaddstr(rpc, NULL, "type") == -1)
		errx(2, "%s", "error while adding \"type\"");
	if (zrpcaddstr(rpc, NULL, "port") == -1)
		errx(2, "%s", "error while adding \"port\"");
	if (zrpcaddstr(rpc, NULL, "ip") == -1)
		errx(2, "%s", "error while adding \"ip\"");
	if (zrpcaddstr(rpc, NULL, "dns") == -1)
		errx(2, "%s", "error while adding \"dns\"");
	if (zrpcaddstr(rpc, NULL, "main") == -1)
		errx(2, "%s", "error while adding the \"main\" object");
	if (zrpcclosearray(rpc) == -1)
		errx(2, "%s", "error while closing array");

	if (zrpcaddarray(rpc, "hostids") == -1)
		errx(2, "%s", "error while adding array");
	if (addhosts(rpc, argv) == -1)
		errx(2, "%s", "error while adding hosts");
	if (zrpcclosearray(rpc) == -1)
		errx(2, "%s", "error while closing array");

	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing obj");
	if (zrpcclose(rpc) == -1)
		errx(2, "%s", "error while closing payload");

	if (zrpcdo(rpc) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("stdio", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL)
			continue;
		if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
		else if (strcmp(val.str, "interfaceid") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "hostid") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "type") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			it = atoi(val.str);
			for (ifp = ifaces; ifp->type != IFERR; ifp++)
				if (ifp->type == it) {
					printf("%s\t", ifp->key);
					break;
				}
			if (ifp->type == IFERR)
				return 3;
		} else if (strcmp(val.str, "port") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "ip") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "dns") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "main") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			if (strcmp(val.str, "0") == 0)
				printf("\n");
			else
				printf("%s\n", "default");
		}
	}

	return 0;
}

int
addhosts(struct zrpc *rpc, char **argv)
{
	char	*lp;
	ssize_t	s;
	size_t	bs;

	lp = NULL;
	bs = 0;
	if (*argv) {

		for (; *argv; argv++)
			if (zrpcaddstr(rpc, NULL, *argv) == -1)
				return -1;
	} else {
		do {
			s = getline(&lp, &bs, stdin);
			if (ferror(stdin))
				return -1;
			if (s == -1)
				continue;
			lp[s - 1] = '\0';

			if (zrpcaddstr(rpc, NULL, lp) == -1)
				return -1;
		} while (!feof(stdin));
	}

	return 0;
}
