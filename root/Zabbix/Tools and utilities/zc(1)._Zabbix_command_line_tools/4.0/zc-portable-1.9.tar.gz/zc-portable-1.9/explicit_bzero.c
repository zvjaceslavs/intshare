/*	$OpenBSD: explicit_bzero.c,v 1.4 2015/08/31 02:53:57 guenther Exp $ */
/*	$Id: explicit_bzero.c,v 1.1 2020/02/15 22:22:23 absc Exp $	*/
/*
 * Public domain.
 * Written by Matthew Dempsky.
 */

#include <string.h>

#include "compat.h"

__attribute__((weak)) void
__explicit_bzero_hook(void *buf, size_t len)
{
}

void
explicit_bzero(void *buf, size_t len)
{
	memset(buf, 0, len);
	__explicit_bzero_hook(buf, len);
}
