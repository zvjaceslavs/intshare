/* $Id: zchostinterfaceadd.c,v 1.6 2020/12/29 21:05:24 absc Exp $ */
/*
 * Copyright (c) 2019 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>

#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

static __dead void	usage(void);

int
main(int argc, char *argv[])
{
	extern struct iface		ifaces[];
	extern struct snmp		snmps[];
	extern struct seclevel	seclevels[];
	extern struct authproto	authprotos[];
	extern struct privproto	privprotos[];
	struct jsonv		val;
	char			fp[PATH_MAX];
	char			url[URLLEN], tok[TOKLEN], ver[TOKLEN];
	struct zrpc		*rpc;
	struct iface		*ifp;
	struct snmp		*snmpp;
	struct seclevel		*sl;
	struct authproto		*ap;
	struct privproto		*pp;
	char			*ip, *dns, *error, *port, *community;
	char			*sname, *aphrase, *pphrase, *ctx;
	enum ifacetype		tp;
	enum snmptype		snp;
	enum secleveltype		slt;
	enum authprototype		apt;
	enum privprototype		ppt;
	int			c, s, mainobj, bulk;

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "r") == -1)
		err(1, "%s", "unveil");

	if (pledge("dns rpath stdio inet", NULL) == -1)
		err(1, "%s", "pledge");

	community = "public";
	bulk = mainobj = 0;
	ip = dns = sname = aphrase = pphrase = ctx = NULL;
	port = DEFAULTPORT;
	tp = IFERR;
	snp = SNMPv2c;
	slt = SLNOAUTHNOPRIV;
	apt = APMD5;
	ppt = PPROTODES;
	while ((c = getopt(argc, argv, "A:a:bc:C:md:i:l:p:P:s:t:v:V:")) != -1)
		switch (c) {
		case 'A':
			for (ap = authprotos; ap->type != APERR; ap++)
				if (strcmp(optarg, ap->key) == 0)
					apt = ap->type;
			break;
		case 'a':
			aphrase = optarg;
			break;
		case 'b':
			bulk = 1;
			break;
		case 'c':
			community = optarg;
			break;
		case 'C':
			ctx = optarg;
			break;
		case 'm':
			mainobj = 1;
			break;
		case 'd':
			dns = optarg;
			break;

		case 'i':
			ip = optarg;
			break;
		case 'l':
			for (sl = seclevels; sl->type != SLERR; sl++)
				if (strcmp(optarg, sl->key) == 0)
					slt = sl->type;
			break;
		case 'p':
			port = optarg;
			break;
		case 'P':
			pphrase = optarg;
			break;
		case 's':
			sname = optarg;
			break;
		case 't':
			for (ifp = ifaces; ifp->type != IFERR; ifp++)
				if (strcmp(optarg, ifp->key) == 0)
					tp = ifp->type;
			break;
		case 'V':
			for (pp = privprotos; pp->type != PPROTOERR; pp++)
				if (strcmp(optarg, pp->key) == 0)
					ppt = pp->type;
			break;
		case 'v':

			for (snmpp = snmps; snmpp->type != SNMPERR; snmpp++)
				if (strcmp(optarg, snmpp->key) == 0)
					snp = snmpp->type;
			break;
		case '?':
			usage();
		}
	argc -= optind;
	argv += optind;

	if (!dns && !ip)
		errx(1, "%s", "at least one option between -d and -i "
		    "must be specified");

	if (tp == IFERR)
		errx(1, "%s", "missing or bad interface type");
	if (snp == SNMPERR)
		errx(1, "%s", "missing or bad SNMP version");
	if (slt == SLERR)
		errx(1, "%s", "bad security level specified");
	if (ppt == PPROTOERR)
		errx(1, "%s", "bad privacy protocol");
	if (apt == APERR)
		errx(1, "%s", "bad authentication protocol");

	if (argc == 0)
		errx(1, "%s", "missing host");

	if (getauthinfo(url, tok, ver) == -1)
		err(1, "%s", fp);

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	rpc = zrpcinit(url, "hostinterface.create", tok, NULL);
	if (!rpc)
		errx(2, "%s", "failed to initialized rpc structure");

	if (zrpcaddobj(rpc, "params") == -1)
		errx(2, "%s", "error while adding \"params\" object");

	if (zrpcaddstr(rpc, "hostid", *argv) == -1)
		errx(2, "%s", "error while adding hostid");
	if (zrpcaddint(rpc, "useip", dns ? 0 : 1) == -1)
		errx(2, "%s", "error while adding \"useip\" object");

	if (zrpcaddstr(rpc, "dns", dns ? dns : "") == -1)
		errx(2, "%s", "error while adding \"dns\" object");
	if (zrpcaddstr(rpc, "ip", ip ? ip : "") == -1)
		errx(2, "%s", "error while adding \"ip\" object");

	if (zrpcaddstr(rpc, "port", port) == -1)
		errx(2, "%s", "error while adding \"port\" object");
	if (zrpcaddint(rpc, "main", mainobj) == -1)
		errx(2, "%s", "error while adding \"main\" object");
	if (zrpcaddint(rpc, "type", tp) == -1)
		errx(2, "%s", "error while adding \"type\" object");

	if (tp == IFSNMP) {
		if (ver[0] == '5') {
			if (zrpcaddobj(rpc, "details") == -1)
				errx(2, "%s", "error while adding "
				    "\"details\" object");
			if (zrpcaddint(rpc, "bulk", bulk) == -1)
				errx(2, "%s", "error while adding "
				    "\"bulk\" object");
			if (zrpcaddstr(rpc, "community", community) == -1)
				errx(2, "%s", "error while adding "
				    "\"community\" object");
			if (zrpcaddint(rpc, "version", snp) == -1)
				errx(2, "%s", "error while adding "
				    "\"version\" object");
			if (sname)
				if (zrpcaddstr(rpc, "securityname", sname) == -1)
					errx(2, "%s", "error while adding "
					    "\"securityname\" object");
			if (zrpcaddint(rpc, "securitylevel", slt) == -1)
				errx(2, "%s", "error while adding "
				    "\"securitylevel\" object");
			if (aphrase)
				if (zrpcaddstr(rpc, "authpassphrase", aphrase) == -1)
					errx(2, "%s", "error while adding "
					    "\"authpassphrase\" object");
			if (pphrase)
				if (zrpcaddstr(rpc, "privpassphrase", pphrase) == -1)
					errx(2, "%s", "error while adding "
					    "\"privpassphrase\" object");
			if (ctx)
				if (zrpcaddstr(rpc, "contextname", ctx) == -1)
					errx(2, "%s", "error while adding "
					    "\"contextname\" object");
			if (zrpcaddint(rpc, "authprotocol", apt) == -1)
				errx(2, "%s", "error while adding "
				    "\"authprotocol\" object");
			if (zrpcaddint(rpc, "privprotocol", ppt) == -1)
				errx(2, "%s", "error while adding "
				    "\"privprotocol\" object");
			if (zrpccloseobj(rpc) == -1)
				errx(2, "%s", "error while closing "
				    "object");
		} else {
			if (zrpcaddint(rpc, "bulk", bulk) == -1)
				errx(2, "%s", "error while adding "
				    "\"bulk\" object");
		}
	}

	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing object");
	if (zrpcclose(rpc) == -1)
		errx(2, "%s", "error while closing payload");

	if (zrpcdo(rpc) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("stdio", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL &&
		    val.type != JSONV_ARR)
			continue;
		if (val.type == JSONV_ARR) {
			for (s = val.size; s > 0; s--) {
				if (zrpcjsonnext(rpc, &val) == -1)
					return 3;
				printf("%s\n", val.str);
			}
		} else if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
	}

	return 0;
}

static __dead void
usage(void)
{
	fprintf(stderr, "%s:\t%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",
	    "usage", getprogname(), "[-bm]", "[-A authproto]", "[-C contextname]",
	    "[-P privpassphrase]", "[-V privproto]", "[-a authpassphrase]",
	    "[-c community]", "[-d hostname]", "[-l securitylevel]", "[-p port]",
	    "[-s securityname]", "[-t type]", "[-v snmpversion]", "hostid");
	fprintf(stderr, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",
	    getprogname(), "[-bm]", "[-A authproto]", "[-C contextname]",
	    "[-P privpassphrase]", "[-V privproto]", "[-a authpassphrase]",
	    "[-c community]", "[-i ip]", "[-l securitylevel]", "[-p port]",
	    "[-s securityname]", "[-t type]", "[-v snmpversion]", "hostid");
	exit(1);
}
