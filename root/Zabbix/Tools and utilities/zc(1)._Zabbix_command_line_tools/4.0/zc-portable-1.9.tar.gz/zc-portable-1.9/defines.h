/* $Id: defines.h,v 1.1.1.1 2020/01/16 20:46:14 absc Exp $ */
/*
 * Copyright (c) 2018 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef _DEFINES_H_
#define _DEFINES_H_

#define STRLEN		1024
#define ARRLEN		1024

#define USERLEN		256
#define PASSWDLEN	256
#define URLLEN		257
#define TOKLEN		34
#define SEVNUM		8
#define JTOKMIN		32

#define TOKFILE		".zc"

#define DEFSRV		"http://localhost/zabbix/api_jsonrpc.php"
#define DEFUSER		"Admin"
#define DEFPASSWD		"zabbix"

#define DEFAULTIP		"127.0.0.1"
#define DEFAULTPORT	"10050"

#define	CAFILE		"/etc/ssl/cert.pem"
#define	CTXDIR		".zc.d"
#define	DEFCTX		"default"

#endif /* !_DEFINES_H_ */
