/* $Id: zc.c,v 1.2 2020/02/09 21:34:03 absc Exp $ */
/*
 * Copyright (c) 2018-2019 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>
#include <sys/stat.h>

#include <err.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "pathnames.h"

struct cmd {
	char	*key;
	char	*cmd;
	char	*pname;
} cmds[] = {
	{"application", LIBEXEC"/zcapplication", "zc application"},
	{"auth", LIBEXEC"/zcauth", "zc auth"},
	{"close", LIBEXEC"/zclose", "zc close"},
	{"config", LIBEXEC"/zcconfig", "zc config"},
	{"event", LIBEXEC"/zcevent", "zc event"},
	{"host", LIBEXEC"/zchost", "zc host"},
	{"hostgroup", LIBEXEC"/zchostgroup", "zc hostgroup"},
	{"item", LIBEXEC"/zcitem", "zc item"},
	{"trigger", LIBEXEC"/zctrigger", "zc trigger"},
	{"history", LIBEXEC"/zchistory", "zc history"},
	{"problem", LIBEXEC"/zcproblem", "zc problem"},
	{"proxy", LIBEXEC"/zcproxy", "zc proxy"},
	{"template", LIBEXEC"/zctemplate", "zc template"},
	{NULL, NULL, NULL}
};

static __dead void	usage(void);
static int		upgrade(void);

int
main(int argc, char *argv[])
{
	char		zcvar[STRLEN], home[STRLEN];
	char		*ev[3];
	char		*ctx;
	struct cmd	*np;
	int		c;

	if (upgrade() == -1)
		exit(1);

	if (pledge("exec proc stdio", NULL) == -1)
		err(1, "%s", "pledge");

	ctx = getenv("ZC_CTX");
	if (!ctx)
		ctx = DEFCTX;

	while ((c = getopt(argc, argv, "c:")) != -1)
		switch (c) {
		case 'c':
			ctx = optarg;
			break;
		case '?':
			usage();
		}
	argc -= optind;
	argv += optind;

	if (argc == 0)
		usage();
	for (np = cmds; np->key != NULL; np++) {
		if (strcmp(*argv, np->key) == 0)
			break;
	}

	if (np->key == NULL)
		usage();

	ev[2] = NULL;
	ev[0] = getenv("HOME");
	if (!ev[0])
		errx(2, "%s", "HOME environment variable not set");
	if (snprintf(home, STRLEN, "%s=%s", "HOME", ev[0]) >= STRLEN)
		errx(2, "%s", "HOME value too long");
	ev[0] = home;

	if (snprintf(zcvar, STRLEN, "%s=%s", "ZC_CTX", ctx) >= STRLEN)
		errx(2, "%s", "ZC_CTX value too long");

	ev[1] = zcvar;

	*argv = np->pname;
	if (execvpe(np->cmd, argv, ev) == -1)
		err(2, "execv");

	return 0;
}

static __dead void
usage(void)
{
	struct cmd	*np;

	fprintf(stderr, "%s:\n", "possibilities are");
	for (np = cmds; np->key != NULL; np++)
		fprintf(stderr, "%s\n", np->key);

	exit(1);
}


static int
upgrade(void)
{
	char	p[STRLEN], p1[STRLEN];
	struct stat	st;
	char	*h;

	h = getenv("HOME");
	if (!h) {
		warnx("%s", "HOME does not exist");
		return -1;
	}

	if (snprintf(p, STRLEN, "%s/%s", h, CTXDIR) >= STRLEN) {
		warnx("%s", "path too long");
		return -1;
	}

	if (mkdir(p, S_IRWXU) == -1) {
		if (errno != EEXIST) {
			warn("%s", "mkdir");
			return -1;
		}
	}

	if (snprintf(p, STRLEN, "%s/%s", h, TOKFILE) >= STRLEN) {
		warnx("%s", "path too long");
		return -1;
	}

	if (stat(p, &st) == 0) {
		if (S_ISREG(st.st_mode) != 0) {
			if (snprintf(p1, STRLEN, "%s/%s/%s", h,
			    CTXDIR, "default") >= STRLEN) {
				warnx("%s", "path too long");
				return -1;
			}
			if (link(p, p1) == -1) {
				if (errno != EEXIST) {
					warn("%s", "link");
					return -1;
				}
			}
		}
	}

	return 0;
}
