/* $Id: zchistoryfloat.c,v 1.3 2020/12/28 09:57:18 absc Exp $ */
/*
 * Copyright (c) 2018 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>
#include <sys/types.h>

#include <err.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

static __dead void	usage(void);
static int		additems(struct zrpc *, char **);

int
main(int argc, char *argv[])
{
	struct jsonv	val;
	struct tm		sts, ets;
	struct zrpc	*rpc;
	char		fp[PATH_MAX];
	char		url[URLLEN], tok[TOKLEN], *error;
	time_t		st, et;
	int		c;

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "r") == -1)
		err(1, "%s", "unveil");

	if (pledge("dns rpath stdio inet", NULL) == -1)
		err(1, "%s", "pledge");

	st = et = 0;
	while ((c = getopt(argc, argv, "e:s:")) != -1)
		switch (c) {
		case 'e':
			explicit_bzero(&ets, sizeof(ets));
			if (!strptime(optarg, "%FT%T", &ets))
				errx(1, "%s: %s", optarg, "bad value");
			et = mktime(&ets);
			if (et == -1)
				errx(1, "%s: %s", optarg, "bad value");
			break;
		case 's':
			explicit_bzero(&sts, sizeof(sts));
			if (!strptime(optarg, "%FT%T", &sts))
				errx(1, "%s: %s", optarg, "bad value");
			st = mktime(&sts);
			if (st == -1)
				errx(1, "%s: %s", optarg, "bad value");
			break;
		case '?':
			usage();
		}
	argv += optind;

	if (getauthinfo(url, tok, NULL) == -1)
		err(1, "%s", fp);

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	rpc = zrpcinit(url, "history.get", tok, NULL);
	if (!rpc)
		errx(2, "%s", "failed to initialized rpc structure");

	if (zrpcaddobj(rpc, "params") == -1)
		errx(2, "%s", "error while adding \"params\" object");

	if (zrpcaddint(rpc, "history", VFLOAT) == -1)
		errx(2, "%s", "error while adding \"history\" value type");

	if (st > 0)
		if (zrpcaddint(rpc, "time_from", st) == -1)
			errx(2, "%s", "error while adding \"time_from\"");
	if (et > 0)
		if (zrpcaddint(rpc, "time_till", et) == -1)
			errx(2, "%s", "error while adding \"time_till\"");

	if (additems(rpc, argv) == -1)
		errx(2, "%s", "error while adding item ids");

	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing object");
	if (zrpcclose(rpc) == -1)
		errx(2, "%s", "error while closing payload");

	if (zrpcdo(rpc) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("stdio", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL)
			continue;
		if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
		else if (strcmp(val.str, "itemid") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "clock") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "value") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\t", val.str);
		} else if (strcmp(val.str, "ns") == 0) {
			if (zrpcjsonnext(rpc, &val) == -1)
				continue;
			printf("%s\n", val.str);
		}
	}

	return 0;
}

static __dead void
usage(void)
{
	fprintf(stderr, "%s: %s %s %s %s\n", "usage", getprogname(),
	    "[-e end]", "[-s start]", "[itemid ...]");
	exit(1);
}

static int
additems(struct zrpc *rpc, char **argv)
{
	char	*lp;
	ssize_t	s;
	size_t	bs;

	lp = NULL;
	bs = 0;
	if (*argv) {
		if (zrpcaddarray(rpc, "itemids") == -1)
			return -1;

		for (; *argv; argv++)
			if (zrpcaddstr(rpc, NULL, *argv) == -1)
				return -1;

		if (zrpcclosearray(rpc) == -1)
			return -1;
	} else {
		if (zrpcaddarray(rpc, "itemids") == -1)
			return -1;

		do {
			s = getline(&lp, &bs, stdin);
			if (ferror(stdin))
				return -1;
			if (s == -1)
				continue;
			lp[s - 1] = '\0';

			if (zrpcaddstr(rpc, NULL, lp) == -1)
				return -1;
		} while (!feof(stdin));

		if (zrpcclosearray(rpc) == -1)
			return -1;
	}

	return 0;
}
