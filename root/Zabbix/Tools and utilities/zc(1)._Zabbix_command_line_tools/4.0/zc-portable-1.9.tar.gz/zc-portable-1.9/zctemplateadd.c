/* $Id: zctemplateadd.c,v 1.3 2020/12/28 09:57:18 absc Exp $ */
/*
 * Copyright (c) 2019 Andrea Biscuola <a@abiscuola.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/cdefs.h>

#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

#include <curl/curl.h>

#include "compat.h"

#include "common.h"
#include "defines.h"
#include "jsmn.h"
#include "zrpc.h"

static __dead void	usage(void);
static int		addgrps(struct zrpc *,  char **);
static int		addhsts(struct zrpc *,  char **);
static int		addtmpls(struct zrpc *, char **);
static int		addmacros(struct zrpc *, char **);

int
main(int argc, char *argv[])
{
	struct jsonv	val;
	char		fp[PATH_MAX];
	char		*grp[ARRLEN], *hst[ARRLEN];
	char		*mcr[ARRLEN], *tmpl[ARRLEN];
	char		tok[TOKLEN], url[URLLEN];
	struct zrpc	*rpc;
	char		*error, **grpp, **hstp, **mcrp, **tmplp;
	size_t		s;
	int		c;

	if (gettokpath(fp) == -1)
		err(1, "%s", "gettokpath");
	if (unveil(CAFILE, "r") == -1)
		err(1, "%s", "unveil");
	if (unveil(fp, "r") == -1)
		err(1, "%s", "unveil");

	if (pledge("dns rpath stdio inet", NULL) == -1)
		err(1, "%s", "pledge");

	grpp = grp;
	hstp = hst;
	mcrp = mcr;
	tmplp = tmpl;
	*grpp = *hstp = *mcrp = *tmplp = NULL;
	while ((c = getopt(argc, argv, "g:h:m:t:")) != -1)
		switch (c) {
		case 'g':
			if (grpp == grp + ARRLEN)
				errx(1, "%s", "too many hostgroups");
			*grpp++ = optarg;
			*grpp = NULL;
			break;
		case 'h':
			if (hstp == hst + ARRLEN)
				errx(1, "%s", "too many hosts");
			*hstp++ = optarg;
			*hstp = NULL;
			break;
		case 'm':
			if (mcrp == mcr + ARRLEN)
				errx(1, "%s", "too many macros");
			*mcrp++ = optarg;
			*mcrp = NULL;
			break;
		case 't':
			if (tmplp == tmpl + ARRLEN)
				errx(1, "%s", "too many templates");
			*tmplp++ = optarg;
			*tmplp = NULL;
			break;
		case '?':
			usage();
		}
	argc -= optind;
	argv += optind;
	if (argc == 0)
		errx(1, "%s", "missing template name");

	if (getauthinfo(url, tok, NULL) == -1)
		err(1, "%s", fp);

	if (zrpcglobalinit(&error) == -1)
		errx(1, "%s", error);

	rpc = zrpcinit(url, "template.create", tok, NULL);
	if (!rpc)
		errx(2, "%s", "failed to initialized rpc structure");

	if (zrpcaddobj(rpc, "params") == -1)
		errx(2, "%s", "error while adding \"params\" object");
	if (zrpcaddstr(rpc, "host", argv[0]) == -1)
		errx(2, "%s", "error while adding template name");
	if (addgrps(rpc, grp) == -1)
		errx(2, "%s", "error while adding groups");
	if (addhsts(rpc, hst) == -1)
		errx(2, "%s", "error while adding hosts");
	if (addtmpls(rpc, tmpl) == -1)
		errx(2, "%s", "error while adding templates");
	if (addmacros(rpc, mcr) == -1)
		errx(2, "%s", "error while adding macros");
	if (zrpccloseobj(rpc) == -1)
		errx(2, "%s", "error while closing object");
	if (zrpcclose(rpc) == -1)
		errx(2, "%s", "error while closing payload");

	if (zrpcdo(rpc) == -1)
		errx(3, "%s", rpc->b);

	if (pledge("stdio", NULL) == -1)
		err(1, "%s", "pledge");

	while (zrpcjsonnext(rpc, &val) != -1) {
		if (val.type != JSONV_STR && val.type != JSONV_VAL &&
		    val.type != JSONV_ARR)
			continue;
		if (val.type == JSONV_ARR) {
			for (s = val.size; s > 0; s--) {
				if (zrpcjsonnext(rpc, &val) == -1)
					return 3;
				printf("%s\n", val.str);
			}
		} else if (strcmp(val.str, "error") == 0)
			errx(3, "%s", zrpcgeterror(rpc));
	}

	return 0;
}

static __dead void
usage(void)
{
	fprintf(stderr, "%s: %s %s %s %s %s %s\n", "usage", getprogname(), "[-g groupid]",
	    "[-h hostid]", "[-m macro=value]", "[-t templateid]", "name");
	exit(1);
}

int
addgrps(struct zrpc *rpc, char **grps)
{
	char	**np;

	if (!*grps)
		return 0;

	if (zrpcaddarray(rpc, "groups") == -1)
		return -1;

	for (np = grps; *np; np++) {
		if (zrpcaddobj(rpc, NULL) == -1)
			return -1;
		if (zrpcaddstr(rpc, "groupid", *np) == -1)
			return -1;
		if (zrpccloseobj(rpc) == -1)
			return -1;
	}

	if (zrpcclosearray(rpc) == -1)
		return -1;

	return 0;
}

int
addhsts(struct zrpc *rpc, char **hsts)
{
	char	**np;

	if (!*hsts)
		return 0;

	if (zrpcaddarray(rpc, "hosts") == -1)
		return -1;

	for (np = hsts; *np; np++) {
		if (zrpcaddobj(rpc, NULL) == -1)
			return -1;
		if (zrpcaddstr(rpc, "hostid", *np) == -1)
			return -1;
		if (zrpccloseobj(rpc) == -1)
			return -1;
	}

	if (zrpcclosearray(rpc) == -1)
		return -1;

	return 0;
}

int
addtmpls(struct zrpc *rpc, char **tmpls)
{
	char	**np;

	if (!*tmpls)
		return 0;

	if (zrpcaddarray(rpc, "templates") == -1)
		return -1;

	for (np = tmpls; *np; np++) {
		if (zrpcaddobj(rpc, NULL) == -1)
			return -1;
		if (zrpcaddstr(rpc, "templateid", *np) == -1)
			return -1;
		if (zrpccloseobj(rpc) == -1)
			return -1;
	}

	if (zrpcclosearray(rpc) == -1)
		return -1;

	return 0;
}

int
addmacros(struct zrpc *rpc, char **macros)
{
	char	**np, *macro, *val;

	if (!*macros)
		return 0;

	if (zrpcaddarray(rpc, "macros") == -1)
		return -1;

	for (np = macros; *np; np++) {
		val = *np;
		macro = strsep(&val, "=");
		if (zrpcaddobj(rpc, NULL) == -1)
			return -1;
		if (zrpcaddstr(rpc, "macro", macro) == -1)
			return -1;
		if (!val)
			return -1;

		if (zrpcaddstr(rpc, "value", val) == -1)
			return -1;
		if (zrpccloseobj(rpc) == -1)
			return -1;
	}

	if (zrpcclosearray(rpc) == -1)
		return -1;

	return 0;
}
