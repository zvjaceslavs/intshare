# Zabbix Media Type for Google Chat

