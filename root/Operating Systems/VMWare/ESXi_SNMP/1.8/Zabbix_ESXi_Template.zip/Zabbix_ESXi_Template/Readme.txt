Author: Andrew Single (andrew.single@frontiersd.mb.ca)
This template is provided free for use & distribution.

The template has been tested on VMWare ESXi 5.0 & 5.1.

Versions
4/29/2014: Datastore detection required the MIB HOST-RESOURCES-MIB to be present.  I've changed it to not require the MIB.