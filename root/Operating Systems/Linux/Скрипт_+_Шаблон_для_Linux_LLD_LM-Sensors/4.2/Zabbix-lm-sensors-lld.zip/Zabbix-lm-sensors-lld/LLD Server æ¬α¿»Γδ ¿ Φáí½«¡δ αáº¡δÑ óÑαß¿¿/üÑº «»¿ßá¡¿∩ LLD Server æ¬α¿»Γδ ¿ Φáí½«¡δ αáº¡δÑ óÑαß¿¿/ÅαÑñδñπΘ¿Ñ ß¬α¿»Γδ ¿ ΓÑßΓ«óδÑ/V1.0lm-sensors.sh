#!/bin/bash
# 2019/05/20 v1.0
# При работе скрипта вся нагрузка выполнения ложится на ресурсы железа Заббикс Сервера!
# Скрипт мониторинга для lm-sensors с LLD для Zabbix (серверный вариант)

# Автообнаружение параметров из Lm-sensor
# Ключ: discovery temp/in/fan

# $1 - это IP и порт узла подключаемого агента
# $2 - Поиск элементов вывод JSON data, temperature, maxtemp, info,
# $3 - Входящая переменная из команды

IFS=$'\n'
JSON="{\"data\":["
SEP=""

if [[ $2 = "discovery" ]]
then
   get=`zabbix_get -s $1 -k system.run["sensors"]`
    obr=`echo "${get}" | grep °C | awk '{print NR "" $0 }' | cut -d":" -f1 | tr -d ' '`
     if [[ -n ${obr} ]]; then
   for NAMETEMP in ${obr};
   do
        JSON=$JSON"$SEP{\"{#NAMETEMP}\":\"$NAMETEMP\"}"
        SEP=", "
done
JSON=$JSON"]}"
echo $JSON
     fi

# Подстановка имени датчика температуры например Core0 lm-sensors.sh[{HOST.CONN},temperatyra,Core0]
# Получение полной информации по команде sensors lm-sensors.sh[{HOST.CONN},info]
# Получение из всех доступных температур максимальной температуры lm-sensors.sh[{HOST.CONN},maxtemp]

else
        if [[ $2 = "temperatura" ]]
        then
        get=`zabbix_get -s $1 -k system.run["sensors"]`
        imyatemp=`echo "${get}" | tr -d ' ' | grep °C | awk '{print NR "" $0 }' | grep $3:| cut -f 2 -d +| grep -oE '^..'`
        for out in $imyatemp
        do
        echo $out
        done
        elif [[ $2 = "maxtemp" ]]
        then
        get1=`zabbix_get -s $1 -k system.run["sensors"]`
        maxc=`echo "${get1}" | tr -d ' ' | grep °C | cut -f 2 -d +| grep -oE '^..' | sort -nk1 | tail -n 1`
        for out in $maxc
        do
        echo $out
        done
        elif [[ $2 = "info" ]]
        then
        get=`zabbix_get -s $1 -k system.run["sensors"]`
        for out in ${get}
        do
        echo "${out}"
        done
        fi
fi
