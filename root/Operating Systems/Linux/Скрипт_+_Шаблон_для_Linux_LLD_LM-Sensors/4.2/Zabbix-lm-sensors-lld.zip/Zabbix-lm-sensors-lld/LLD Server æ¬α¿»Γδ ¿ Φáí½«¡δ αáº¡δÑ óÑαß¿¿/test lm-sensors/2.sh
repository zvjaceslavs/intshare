#!/bin/bash
get="cat 2"
EGREP="/bin/egrep"
TR="/usr/bin/tr"
CUT="/usr/bin/cut"

/bin/cat << END
{
     "data":[
END

SEP=""
for chip in $($get -u 2>/dev/null|$EGREP "^[^:]+$")
do
        while read sensor
        do
            case $sensor in
               temp*)
                  UNITS="°C"
                  ;;
               in*)
                  UNITS="V"
                  ;;
               fan*)
                  UNITS="RPM"
                  ;;
               *)
                  UINTS=""
                  ;;
             esac
             /bin/echo -e "\t\t{\"{#CHIP}\":\"$chip\", \"{#SENSOR}\":\"$sensor\", \"{#UNITS}\":\"$UNITS\"}$SEP"
             SEP=","
done <<<$($get -u $chip 2>/dev/null|$EGREP "_input:"|$TR -d " "|$CUT -d_ -f1)
done|tac

/bin/cat << END
	]
}
END
