#!/bin/bash
#2019/08/12 v3.0
#При работе скрипта вся нагрузка выполнения ложится на ресурсы железа Заббикс Сервера!
#Скрипт мониторинга для lm-sensors с LLD для Zabbix (серверный вариант)
# Автор Мамзиков Артём Андреевич Описание по скрипту https://diyit.ru/viewtopic.php?f=48&t=52

#Автообнаружение параметров из Lm-sensor
#Ключ: discovery temp/in/fan

# $1 - это IP и порт узла подключаемого агента
# $2 - Поиск элементов вывод JSON data, temperature, maxtemp, info,
# $3 - Входящая переменная из команды

IFS=$'\n'
JSON="{\"data\":["
SEP=""

if [[ $2 = "discovery" ]]
then
# Запуск переменной get команды sensors -u
get=`zabbix_get -s $1 -k system.run["sensors -u"]`
# 1шаг Выбираем имена чипов в переменную chip если ошибка отправка в черную дыру
for chip in $(echo "${get}" 2>/dev/null|grep -E "^[^:]+$")
do
# Запуск переменной filter это команда sensors -u с подстановкой перебором имён чипа которые получены в переменной chip (фильтрация по чипам)
#filter=`zabbix_get -s $1 -k system.run["sensors -u $chip"]`
# взято из переменной выше
filter=$(echo "${get}" 2>/dev/null| sed -n "/"${chip}"/,/^$/p")
#echo "${filter}"
        # чтение сенсоров получение переменной sensor
        while read sensor
        do
#3шаг Поиск строк содержащие например temp значит температура выше имени температуры взять имя чья температура и присвоить Ед. измерения °C и т.д.
   case $sensor in
       temp*)
	     # Вывод переменной filter| взять значение из предыдущей строки от значения $sensor | Обрезать двоеточие| удалить пробелы
         NAMETEMP=`echo "${filter}" | grep -B1 -P "$sensor"| grep -vP "$sensor"| tr -d ':'| tr -d ' '`
         UNITS="°C"
         ;;
       fan*)
         NAMEFAN=`echo "${filter}" | grep -B1 -P "$sensor"| grep -vP "$sensor"| tr -d ':'| tr -d ' '`
         UNITS="RPM"
         ;;
       in*)
         NAMEVOLT=`echo "${filter}" | grep -B1 -P "$sensor"| grep -vP "$sensor"| tr -d ':'| tr -d ' '`
         UNITS="V"
         ;;
        *)
         UINTS=""
         ;;
   esac
        JSON=$JSON"$SEP\n{\"{#CHIP}\":\"$chip\", \"{#SENSOR}\":\"$sensor\", \"{#NAMETEMP}\":\"$NAMETEMP\", \"{#NAMEFAN}\":\"$NAMEFAN\", \"{#NAMEVOLT}\":\"$NAMEVOLT\", \"{#UNITS}\":\"$UNITS\"}"
        SEP=", "
# Использование строки Here,чтение данных из строки, вместо всего содержимого файла (работает для bash 3+) это перовое do (обрабатываем все в скобках с подстановкой из цикла) и получаем переменные вывода первого do
# Вывод переменной filter если ответ 2 ошибка в черную дыру все|найти строку _input: и оставить значение до ее|  удалить все пробелы| обрезать все после _
done<<<$(echo "${filter}" 2>/dev/null|grep -E "_input:"|tr -d " "|cut -d_ -f1)
# 2шаг обработка построчно запуск filter поиск строк с _input: и вырезка имени до _input: получаем список имён распределенных по чипам
done
# Выводим результат в json data
JSON=$JSON"\n]}"
echo -e $JSON

# Получение полной информации по команде sensors lm-sensors.sh[{HOST.CONN},info]
# Получение из всех доступных температур максимальной температуры lm-sensors.sh[{HOST.CONN},maxtemp
# Вход данных для работы через внешнюю проверку где нет агента  lm-sensors.sh[{HOST.CONN},sensor,{#CHIP},{#SENSOR}]

else
        if [[ $2 = "info" ]]
        then
		# Запуск переменной get команды sensors
        get=`zabbix_get -s $1 -k system.run["sensors"]`
		# Вывод всего листинга команды переменой циклом
        for out in $get
        do
        echo "${out}"
        done
		# Максимальная температура
        elif [[ $2 = "maxtemp" ]]
        then
		# Запуск переменной get1 команды sensors
        get1=`zabbix_get -s $1 -k system.run["sensors"]`
		# Обработка вывод переменой sensors| вырезать все после скобок ( в том числе и саму скобку| убрать пробелы в именах| Поиск (выбор) строк температуры °C|
		# вырезать все до : и само :| вырезать в строке где есть + все что до + и сам + | вырезать . точку и все после нее| сортировка от меньшему к большему | выбор последнего значения 
        maxc=`echo "${get1}" | cut -d"(" -f1 | tr -d ' ' | grep °C | cut -d":" -f2 | cut -f 2 -d + | cut -d"." -f1 | sort -nk1 | tail -n 1`
		# Вывод значения переменной циклом
        for out in $maxc
        do
        echo $out
        done
        elif [[ $2 = "sensor" ]]
        then
		# Запуск переменной vxod с 2 входными данными
        vxod=`zabbix_get -s $1 -k sensor[$3,$4]`
		# Вывод значения переменной циклом
        for out in $vxod
        do
        echo "${out}"
        done
        fi
fi
