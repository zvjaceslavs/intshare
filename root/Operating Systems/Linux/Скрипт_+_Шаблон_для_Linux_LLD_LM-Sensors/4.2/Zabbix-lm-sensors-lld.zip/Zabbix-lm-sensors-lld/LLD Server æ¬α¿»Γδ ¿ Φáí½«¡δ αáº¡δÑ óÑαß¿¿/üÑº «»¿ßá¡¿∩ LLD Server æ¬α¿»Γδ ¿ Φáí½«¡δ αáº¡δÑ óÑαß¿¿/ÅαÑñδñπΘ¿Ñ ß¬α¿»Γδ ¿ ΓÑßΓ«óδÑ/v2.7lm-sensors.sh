#!/bin/bash
# 2019/08/05 v2.7
# При работе скрипта вся нагрузка выполнения ложится на ресурсы железа Заббикс Сервера!
# Скрипт мониторинга для lm-sensors с LLD для Zabbix (серверный вариант)

# $1 - это IP и порт узла подключаемого агента
# $2 - Поиск элементов вывод JSON data по команде sensors -u, и отдельно  maxtemp, info покоманде sensors
# Обратных входных данных нет сформировавшийся ключ работает напрямую (zabbix_get -s IP -k sensor[имя чипа,имя сенсора])

IFS=$'\n'
JSON="{\"data\":["
SEP=""

if [[ $2 = "discovery" ]]
then
get=`zabbix_get -s $1 -k system.run["sensors -u"]`
for chip in $(echo "${get}" 2>/dev/null|grep -E "^[^:]+$")
do
        while read sensor
        do
            case $sensor in
               temp*)
                  UNITS="°C"
                  ;;
               in*)
                  UNITS="V"
                  ;;
               fan*)
                  UNITS="RPM"
                  ;;
               *)
                  UINTS=""
                  ;;
             esac
             JSON=$JSON"$SEP{\"{#CHIP}\":\"$chip\", \"{#SENSOR}\":\"$sensor\", \"{#UNITS}\":\"$UNITS\"}"
             SEP=", "
done <<<$(echo "${get}" $chip 2>/dev/null|grep -E "_input:"|tr -d " "|cut -d_ -f1)
#done|tac
done
JSON=$JSON"]}"
echo $JSON

# Получение полной информации по команде sensors lm-sensors.sh[{HOST.CONN},info]
# Получение из всех доступных температур максимальной температуры lm-sensors.sh[{HOST.CONN},maxtemp]

else
        if [[ $2 = "info" ]]
        then
        get=`zabbix_get -s $1 -k system.run["sensors"]`
        for out in ${get}
        do
        echo "${out}"
        done
        elif [[ $2 = "maxtemp" ]]
        then
        get1=`zabbix_get -s $1 -k system.run["sensors"]`
        maxc=`echo "${get1}" | cut -d"(" -f1 | tr -d ' ' | grep °C | cut -d":" -f2 | cut -f 2 -d + | cut -d"." -f1 | sort -nk1 | tail -n 1`
        for out in $maxc
        do
        echo $out
        done
        fi
fi
