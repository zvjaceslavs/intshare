#!/bin/bash
#2019/08/12 v3.0
#При работе скрипта вся нагрузка выполнения ложится на ресурсы железа Заббикс Сервера!
#Скрипт мониторинга для lm-sensors с LLD для Zabbix (серверный вариант)

#Автообнаружение параметров из Lm-sensor
#Ключ: discovery temp/in/fan

# $1 - это IP и порт узла подключаемого агента
# $2 - Поиск элементов вывод JSON data, temperature, maxtemp, info,
# $3 - Входящая переменная из команды

IFS=$'\n'
JSON="{\"data\":["
SEP=""

if [[ $2 = "discovery" ]]
then
get=`zabbix_get -s $1 -k system.run["sensors -u"]`
# Запуск перменной get команды sensors -u
for chip in $(echo "${get}" 2>/dev/null|grep -E "^[^:]+$")
# 1шаг Выбираем имена чипов в переменную chip если ошибка отправка в черную дыру
do
#filter=`zabbix_get -s $1 -k system.run["sensors -u $chip"]`
# взято из переменной выше
filter=$(echo "${get}" 2>/dev/null| sed -n "/"${chip}"/,/^$/p")
#echo "${filter}"
# Запуск переменной get2 это команда sensors -u с подстановкой перебором имён чипа которые получены в переменной chip (фильтрация по чипам)
        while read sensor
        do
#3шаг Поиск строк содержащие например temp значит температура выше имени темпертары взять имя чья температура и присвоить Ед. змерения °C и т.д.
   case $sensor in
       temp*)
         NAMETEMP=`echo "${filter}" | grep -B1 -P "$sensor"| grep -vP "$sensor"| tr -d ':'| tr -d ' '`
         UNITS="°C"
         ;;
       fan*)
         NAMEFAN=`echo "${filter}" | grep -B1 -P "$sensor"| grep -vP "$sensor"| tr -d ':'| tr -d ' '`
         UNITS="RPM"
         ;;
       in*)
         NAMEVOLT=`echo "${filter}" | grep -B1 -P "$sensor"| grep -vP "$sensor"| tr -d ':'| tr -d ' '`
         UNITS="V"
         ;;
        *)
         UINTS=""
         ;;
   esac
        JSON=$JSON"$SEP{\"{#CHIP}\":\"$chip\", \"{#SENSOR}\":\"$sensor\", \"{#NAMETEMP}\":\"$NAMETEMP\", \"{#NAMEFAN}\":\"$NAMEFAN\", \"{#NAMEVOLT}\":\"$NAMEVOLT\", \"{#UNITS}\":\"$UNITS\"}"
        SEP=", "
done<<<$(echo "${filter}" 2>/dev/null|grep -E "_input:"|tr -d " "|cut -d_ -f1)
# 2шаг обработка построчно запуск get2 поиск строк с _input: и вырезка имени до _input: получаем список имён распределенных по чипам
done
# Выводим результат в json data
JSON=$JSON"]}"
echo $JSON

# Получение полной информации по команде sensors lm-sensors.sh[{HOST.CONN},info]
# Получение из всех доступных температур максимальной температуры lm-sensors.sh[{HOST.CONN},maxtemp
# Вход данных для работы через внешнюю проверку где нет агента  lm-sensors.sh[{HOST.CONN},sensor,{#CHIP},{#SENSOR}]

else
        if [[ $2 = "info" ]]
        then
        get=`zabbix_get -s $1 -k system.run["sensors"]`
        for out in $get
        do
        echo "${out}"
        done
        elif [[ $2 = "maxtemp" ]]
        then
        get1=`zabbix_get -s $1 -k system.run["sensors"]`
        maxc=`echo "${get1}" | cut -d"(" -f1 | tr -d ' ' | grep °C | cut -d":" -f2 | cut -f 2 -d + | cut -d"." -f1 | sort -nk1 | tail -n 1`
        for out in $maxc
        do
        echo $out
        done
        elif [[ $2 = "sensor" ]]
        then
        vxod=`zabbix_get -s $1 -k sensor[$3,$4]`
        for out in $vxod
        do
        echo "${out}"
        done
        fi
fi
