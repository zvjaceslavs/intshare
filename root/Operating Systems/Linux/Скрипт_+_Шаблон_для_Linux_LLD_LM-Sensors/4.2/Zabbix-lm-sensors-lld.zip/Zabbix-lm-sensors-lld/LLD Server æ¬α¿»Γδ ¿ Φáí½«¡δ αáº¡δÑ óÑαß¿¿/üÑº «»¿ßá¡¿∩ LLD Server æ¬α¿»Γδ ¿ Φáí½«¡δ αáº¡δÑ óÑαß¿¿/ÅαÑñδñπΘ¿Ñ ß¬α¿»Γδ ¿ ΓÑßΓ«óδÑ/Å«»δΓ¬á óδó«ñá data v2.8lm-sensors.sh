#!/bin/bash
# testov 2019/08/06 v2.8
#При работе скрипта вся нагрузка выполнения ложится на ресурсы железа Заббикс Сервера!
#Скрипт мониторинга для lm-sensors с LLD для Zabbix (серверный вариант)

#Автообнаружение параметров из Lm-sensor
#Ключ: discovery temp/in/fan
# $1 - это IP и порт узла подключаемого агента
# $2 - Поиск элементов вывод JSON data, temperature, maxtemp, info,
# $3 - Входящая переменная из команды

IFS=$'\n'
JSON="{\"data\":["
SEP=""

if [[ $2 = "discovery" ]]
then
   get=`zabbix_get -s $1 -k system.run["sensors"]`
for chip in $(echo "${get}" 2>/dev/null|grep -E "^[^:]+$")
do
        while read spisoc
        do
   case $spisoc in
       C*)
         NAMETEMP=`echo "${get}" | cut -d"(" -f1 | grep °C | awk '{print NR "" $0 }' | cut -d":" -f1 | tr -d ' '`
         UNITS="°C"
         ;;
       RPM*)
         NAMEFAN=`echo "${get}" | cut -d"(" -f1 | grep RPM | awk '{print NR "" $0 }' | cut -d":" -f1 | tr -d ' '`
         UNITS="RPM"
         ;;
       V*)
         NAMEVOLT=`echo "${get}" | cut -d"(" -f1 | grep V | awk '{print NR "" $0 }' | cut -d":" -f1 | tr -d ' '`
         UNITS="V"
         ;;
        *)
         UINTS=""
         ;;
   esac
        JSON=$JSON"$SEP{\"{#CHIP}\":\"$chip\", \"{#NAMETEMP}\":\"$NAMETEMP\", \"{#NAMEFAN}\":\"$NAMEFAN\", \"{#NAMEVOLT}\":\"$NAMEVOLT\", \"{#UNITS}\":\"$UNITS\"}"
        SEP=", "
done<<<$(echo "${get}" $chip 2>/dev/null| cut -d"(" -f1 | grep : | cut -d":" -f1 | tr -d ' ')
done
JSON=$JSON"]}"
echo $JSON

# Подстановка имени датчика температуры например Core0 lm-sensors.sh[{HOST.CONN},temperatyra,Core0]
# Получение полной информации по команде sensors lm-sensors.sh[{HOST.CONN},info]
# Получение из всех доступных температур максимальной температуры lm-sensors.sh[{HOST.CONN},maxtemp

else
        if [[ $2 = "info" ]]
        then
        get=`zabbix_get -s $1 -k system.run["sensors"]`
        for out in $get
        do
        echo "${out}"
        done
        elif [[ $2 = "temperature" ]]
        then
        get=`zabbix_get -s $1 -k system.run["sensors"]`
        imyatemp=`echo "${get}" | cut -d"(" -f1 | tr -d ' ' | grep °C | awk '{print NR "" $0 }' | grep $3:| cut -d":" -f2 | cut -f 2 -d + | cut -d"." 
-f1`
        for out in $imyatemp
        do
        echo $out
        done
        elif [[ $2 = "maxtemp" ]]
        then
        get1=`zabbix_get -s $1 -k system.run["sensors"]`
        maxc=`echo "${get1}" | cut -d"(" -f1 | tr -d ' ' | grep °C | cut -d":" -f2 | cut -f 2 -d + | cut -d"." -f1 | sort -nk1 | tail -n 1`
        for out in $maxc
        do
        echo $out
        done
		elif [[ $2 = "fan" ]]
        then
        get=`zabbix_get -s $1 -k system.run["sensors"]`
        imyafan=`echo "${get}" | cut -d"(" -f1 | tr -d ' ' | grep RPM | awk '{print NR "" $0 }' | grep $3:| cut -d":" -f2 | cut -f 2 -d + | cut -d"R" 
-f1`
        for out in $imyafan
        do
        echo $out
        done
		elif [[ $2 = "volt" ]]
        then
        get=`zabbix_get -s $1 -k system.run["sensors"]`
        imyavolt=`echo "${get}" | cut -d"(" -f1 | tr -d ' ' | grep V | awk '{print NR "" $0 }' | grep $3:| cut -d":" -f2 | cut -f 2 -d + | cut -d"V" 
-f1`
        for out in $imyavolt
        do
        echo $out
        done
        fi
fi
