#!/bin/bash
# testov 2019/07/30 v2.5
# При работе скрипта вся нагрузка выполнения ложится на ресурсы железа Заббикс Сервера!
# Скрипт мониторинга для lm-sensors с LLD для Zabbix (серверный вариант)

# Автообнаружение параметров из Lm-sensor
# Ключ: discovery temp/in/fan

# $1 - это IP и порт узла подключаемого агента
# $2 - Поиск элементов вывод JSON data, temperature, maxtemp, info,
# $3 - Входящая переменная из команды

IFS=$'\n'
JSON="{\"data\":["
SEP=""

if [[ $1 = "discovery" ]]
then
   get=`cat 1`
    obrTemp=`echo "${get}" | cut -d"(" -f1 | grep °C | awk '{print NR "" $0 }' | cut -d":" -f1 | tr -d ' '`
    obrFan=`echo "${get}" | cut -d"(" -f1 | grep RPM | awk '{print NR "" $0 }' | cut -d":" -f1 | tr -d ' '`
    obrV=`echo "${get}" | cut -d"(" -f1 | grep V | awk '{print NR "" $0 }' | cut -d":" -f1 | tr -d ' '`
#  if [[ -n ${obrTemp} ]];
#  then
   for NAMETEMP in ${obrTemp}; do for NAMEFAN in ${obrFan}; do for NAMEVOLT in ${obrV}; do
        JSON=$JSON"$SEP{\"{#NAMETEMP}\":\"$NAMETEMP\", \"{#NAMEFAN}\":\"$NAMEFAN\", \"{#NAMEVOLT}\":\"$NAMEVOLT\"}"
        SEP=", "
done
done
done
JSON=$JSON"]}"
echo $JSON
#     fi

# Подстановка имени датчика температуры например Core0 lm-sensors.sh[{HOST.CONN},temperatyra,Core0]
# Получение полной информации по команде sensors lm-sensors.sh[{HOST.CONN},info]
# Получение из всех доступных температур максимальной температуры lm-sensors.sh[{HOST.CONN},maxtemp

else
        if [[ $1 = "info" ]]
        then
        get=`cat 1`
        for out in $get
        do
        echo "${out}"
        done
        elif [[ $1 = "temperature" ]]
        then
        get=`cat 1`
        imyatemp=`echo "${get}" | cut -d"(" -f1 | tr -d ' ' | grep °C | awk '{print NR "" $0 }' | grep $2:| cut -d":" -f2 | cut -f 2 -d + | cut -d"." -f1`
        for out in $imyatemp
        do
        echo $out
        done
        elif [[ $1 = "maxtemp" ]]
        then
        get1=`cat 1`
        maxc=`echo "${get1}" | cut -d"(" -f1 | tr -d ' ' | grep °C | cut -d":" -f2 | cut -f 2 -d + | cut -d"." -f1 | sort -nk1 | tail -n 1`
        for out in $maxc
        do
        echo $out
        done
		elif [[ $1 = "fan" ]]
        then
        get=`cat 1`
        imyatemp=`echo "${get}" | cut -d"(" -f1 | tr -d ' ' | grep RPM | awk '{print NR "" $0 }' | grep $2:| cut -d":" -f2 | cut -f 2 -d + | cut -d"R" -f1`
        for out in $imyatemp
        do
        echo $out
        done
		elif [[ $1 = "volt" ]]
        then
        get=`cat 1`
        imyatemp=`echo "${get}" | cut -d"(" -f1 | tr -d ' ' | grep V | awk '{print NR "" $0 }' | grep $2:| cut -d":" -f2 | cut -f 2 -d + | cut -d"V" -f1`
        for out in $imyatemp
        do
        echo $out
        done
        fi
fi