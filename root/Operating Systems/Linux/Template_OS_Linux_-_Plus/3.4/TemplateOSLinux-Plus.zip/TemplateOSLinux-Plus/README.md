# Zabbix_template_linux_OS-plus

See in share.zabbix.com for details.  
https://share.zabbix.com/operating-systems/linux/template-os-linux-plus  

# Release note
2014-02-14 V1.0  
 Release.  
2014-03-04 V1.1  
 Add a graph prototype of folder usage in hostscreen.
 
