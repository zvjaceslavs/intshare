Copy getFanSpeed.rb to "externalscripts" on Zabbix server, and install Ruby. Read README.TXT before using.
The OIDtree of IMM: http://www.oidview.com/mibs/2/IMM-MIB.html
The MIB: download update in IBM Download Center www.ibm.com/support/ , EXTRACT the .exe file
Example: http://www-933.ibm.com/support/fixcentral/systemx/downloadFixes?parent=Cluster%2B1350&product=ibm/systemx/0445&&platform=All&function=fixId&fixids=clust_13a_ibm_fw_imm2_1aoo40z-2.50_anyos_noarch&includeRequisites=1&includeSupersedes=0&downloadMethod=http
Alexey Burov, allburov@gmail.com