<p>Simple template to monitor ipmi hp DL360p G9 server by ipmi protocol by iLO interface.</p>
<p>useful with <a href="cat-server-hardware/hp/ipmi-hp-servers-hdd-discovery">my hp ipmi Drives discovery template</a></p>
<p>Please first corretly configure ipmi interface on node in zabbix web interface.</p>

This pack contains of two different templates:
IPMI HP DL360p Gen9.xml - contains all sensors
IPMI HP DL360p Gen9 noHDD.xml - contains all sensors except hard drives

I prefer use template with noHDD option and my ipmi HDD discovery template,
but you can use any.