# zbx-adaptec-raid
Zabbix Template and PowerShell script with Low Level Discovery (LLD) for LSI Controllers.


## Prerequisites:
 - MegaRAID Storage Manager storcli64.exe (Windows and Linux)
 - Add UserParameter to zabbix-agent config

**Tested on:**
 - AVAGO MegaRAID SAS 9361-4i
 - Windows 2012r2
 - Windows 2016