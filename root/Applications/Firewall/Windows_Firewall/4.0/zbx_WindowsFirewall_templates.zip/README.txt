You need to enable Remote commands in zabbix agent config file

##################
EnableRemoteCommands=1
##################