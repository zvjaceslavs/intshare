## nomad template installation and configuration

### Template configuration zabbix-side
* Import zabbix template file `zabbix_nomad_app_template.xml` on zabbix
* Select a nomad hosts and add `Template App nomad`

### Configuration on nomad server side
* No configuration needed
