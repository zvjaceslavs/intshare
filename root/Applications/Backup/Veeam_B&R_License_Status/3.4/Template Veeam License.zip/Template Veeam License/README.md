# Zabbix template for Veeam license status

### Install

  1. Import template in zabbix web ui
  2. Add UserParameter lines to zabbix agent config file
  3. Copy PS script to c:/zabbix/scripts
  4. Connect template to host
