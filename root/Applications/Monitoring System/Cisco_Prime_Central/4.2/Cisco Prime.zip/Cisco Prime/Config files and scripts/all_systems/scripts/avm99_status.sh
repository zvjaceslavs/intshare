/export/home/pn400/Main/anactl status 2>&1|grep AVM99|grep up|wc -l
