## Traefik template installation and configuration

### Template configuration zabbix-side
* Import zabbix template file `zabbix_traefik_app_template.xml` on zabbix
* Select a traefik hosts and add `Template App traefik`

### Configuration on traefik server side
* No configuration needed
