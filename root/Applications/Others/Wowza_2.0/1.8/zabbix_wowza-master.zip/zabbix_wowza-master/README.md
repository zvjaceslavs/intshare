Wowza Streaming Media Server script for zabbix
=====
wowza.pl script with executable rights must be placed in "externalscripts" directory (usually /etc/zabbix/externalscripts).

You need to pass {WOWZAUSER} and {WOWZAPASS} macros.
