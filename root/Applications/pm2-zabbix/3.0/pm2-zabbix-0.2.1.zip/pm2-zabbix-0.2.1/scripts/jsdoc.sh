#!/bin/sh
mkdir -p jsdoc
jsdoc -d jsdoc lib/
