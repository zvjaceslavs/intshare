# EMC-VNX-Storage-Zabbix-Monitor
一套使用Navisphere命令行工具获取EMC VNX磁阵状态的监控脚本，可运用于Zabbix，可监控磁阵的CPU、DIMM、Disk、I/O、LCC、Power、SP、SPS、SPS Cable。

使用方法及具体介绍参看：[http://www.icoder.top/blog/?p=926](http://www.icoder.top/blog/?p=926)
