# HUAWEI-OceanStor-Sx900-Monitor
这套脚本用于监控华为S系列存储的控制器、框、硬盘、风扇、电源，已在华为S3900、S5900使用过。

使用方法即工作原理参看：《华为Sx900存储的监控》[<http://www.icoder.top/blog/?p=924>](http://www.icoder.top/blog/?p=924)
